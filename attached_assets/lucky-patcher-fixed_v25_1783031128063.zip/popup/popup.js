// Lucky Patcher – Popup v2 (fixed)

let currentTab = "all";
let paused = false;
let currentPage = 0;
let allCaptures = [];
let searchQuery = "";
const PAGE_SIZE = 80;

const captureList    = document.getElementById("captureList");
const panelList      = document.getElementById("panelList");
const panelDetail    = document.getElementById("panelDetail");
const panelStats     = document.getElementById("panelStats");
const panelStack     = document.getElementById("panelStack");
const panelTrace     = document.getElementById("panelTrace");
const panelReplay    = document.getElementById("panelReplay");
const totalCounter   = document.getElementById("totalCounter");
const searchInput    = document.getElementById("searchInput");
const loadMoreWrap   = document.getElementById("loadMore");
const liveIntelBanner = document.getElementById("liveIntelBanner");

const ALL_PANELS = [panelList, panelDetail, panelStats, panelStack, panelTrace, panelReplay, document.getElementById("panelExec")].filter(Boolean);

document.addEventListener("DOMContentLoaded", () => {
  loadCaptures();
  setupTabs();
  setupButtons();
  setupSearch();
  listenForNew();
  listenForTrace();
  listenForReplay();
  listenForExec();
  listenForLiveIntel();
  loadLiveIntel();
});

// ── Tabs ──────────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      // Exec tab has its own dedicated handler in listenForExec — skip here
      if (tab.dataset.tab === "exec") return;

      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      currentTab = tab.dataset.tab;
      currentPage = 0;
      showOnly(null);
      if (currentTab === "stats") { panelStats.classList.remove("hidden"); loadStats(); }
      else if (currentTab === "stack") { panelStack.classList.remove("hidden"); loadStackPanel(); }
      else { panelList.classList.remove("hidden"); loadCaptures(); }
    });
  });
}

function showOnly(panel) {
  ALL_PANELS.forEach(p => { if (p) p.classList.add("hidden"); });
  if (panel) panel.classList.remove("hidden");
}

// ── Buttons ───────────────────────────────────────────────────────────────────
function setupButtons() {
  document.getElementById("btnPause").addEventListener("click", () => {
    paused = !paused;
    const b = document.getElementById("btnPause");
    b.textContent = paused ? "▶" : "⏸"; b.classList.toggle("paused", paused);
  });
  document.getElementById("btnClear").addEventListener("click", () => {
    if (!confirm("Clear all captures?")) return;
    chrome.runtime.sendMessage({ type: "CLEAR_CAPTURES" }, () => { allCaptures = []; captureList.innerHTML = ""; updateCounters(); });
  });
  document.getElementById("btnExport").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "EXPORT_CAPTURES" }, (resp) => {
      dl(new Blob([resp.data], { type: "application/json" }), "lp-" + Date.now() + ".json");
    });
  });
  document.getElementById("btnBack").addEventListener("click", () => { showOnly(panelList); });
  document.getElementById("btnTraceBack").addEventListener("click", () => { showOnly(panelDetail); });
  document.getElementById("btnReplayBack").addEventListener("click", () => { showOnly(panelDetail); });
  document.getElementById("btnLoadMore")?.addEventListener("click", () => { currentPage++; appendCaptures(); });

  // Replay fire button
  document.getElementById("btnFireReplay").addEventListener("click", () => {
    if (!currentReplayCap) return;
    const method = document.getElementById("replayMethod").value;
    const url = document.getElementById("replayUrlInput").value.trim();
    const bodyVal = document.getElementById("replayBody").value;
    let extraHeaders = {};
    try { extraHeaders = JSON.parse(document.getElementById("replayHeaders").value || "{}"); } catch {}
    fireReplay(currentReplayCap, { method, url, headers: extraHeaders, body: bodyVal || null });
  });
}

function setupSearch() {
  let deb;
  searchInput.addEventListener("input", () => { clearTimeout(deb); deb = setTimeout(() => { searchQuery = searchInput.value.trim(); currentPage = 0; loadCaptures(); }, 300); });
}

// ── Data loading ──────────────────────────────────────────────────────────────
function buildFilter() {
  const f = {};
  const nets = ["http","xhr","fetch","websocket","iframe","dom"];
  if (nets.includes(currentTab)) f.captureType = currentTab;
  if (searchQuery) f.search = searchQuery;
  return f;
}

function loadCaptures() {
  chrome.runtime.sendMessage({ type: "GET_CAPTURES", filter: buildFilter(), page: 0, pageSize: PAGE_SIZE }, (resp) => {
    if (!resp) return;
    allCaptures = resp.captures || [];
    renderList(true); updateCounters();
  });
}

function appendCaptures() {
  chrome.runtime.sendMessage({ type: "GET_CAPTURES", filter: buildFilter(), page: currentPage, pageSize: PAGE_SIZE }, (resp) => {
    const items = resp ? resp.captures || [] : [];
    allCaptures = [...allCaptures, ...items];
    for (const c of items) captureList.appendChild(buildCaptureItem(c));
    loadMoreWrap.classList.toggle("hidden", items.length < PAGE_SIZE);
  });
}

function loadStats() { chrome.runtime.sendMessage({ type: "GET_STATS" }, renderStats); }
function loadStackPanel() {
  chrome.runtime.sendMessage({ type: "GET_CAPTURES", filter: { stackOnly: true }, page: 0, pageSize: 200 }, (resp) => renderStackPanel(resp ? resp.captures || [] : []));
}

// ── Render list ───────────────────────────────────────────────────────────────
function renderList(fresh) {
  if (fresh) captureList.innerHTML = "";
  if (!allCaptures.length) {
    captureList.innerHTML = '<div class="empty-state"><div class="empty-icon">&#128373;</div><div>No captures yet</div><div style="font-size:10px;color:var(--text3)">Browse a page to start intercepting</div></div>';
    loadMoreWrap.classList.add("hidden"); return;
  }
  if (fresh) for (const c of allCaptures) captureList.appendChild(buildCaptureItem(c));
  loadMoreWrap.classList.toggle("hidden", allCaptures.length < PAGE_SIZE);
}

function buildCaptureItem(cap) {
  const el = document.createElement("div");
  el.className = "capture-item";
  const tc = "type-" + cap.captureType, time = formatTime(cap.timestamp);
  if (cap.captureType === "websocket") {
    el.innerHTML = '<div class="capture-row1"><span class="cap-type ' + tc + '">WS</span><span class="cap-ws-event">' + esc(cap.event ? cap.event.toUpperCase() : "") + '</span><span class="cap-domain">' + esc(cap.domain || cap.url || "") + '</span><span class="cap-time">' + time + '</span></div>' + (cap.payload ? '<div class="cap-ws-payload">' + esc(cap.payload) + '</div>' : "");
  } else if (cap.captureType === "dom") {
    el.innerHTML = '<div class="capture-row1"><span class="cap-type ' + tc + '">DOM</span><span class="cap-ws-event">&lt;' + esc(cap.tag || "") + '&gt;</span><span class="cap-domain">' + esc(cap.event || "") + '</span><span class="cap-time">' + time + '</span></div>' + (cap.src ? '<div class="cap-url">' + esc(cap.src) + '</div>' : "");
  } else if (cap.captureType === "iframe") {
    el.innerHTML = '<div class="capture-row1"><span class="cap-type ' + tc + '">iframe</span><span class="cap-ws-event">' + esc(cap.event ? cap.event.toUpperCase() : "") + '</span><span class="cap-domain">' + esc(cap.domain || "") + '</span><span class="cap-time">' + time + '</span></div>' + (cap.src ? '<div class="cap-url">' + esc(cap.src) + '</div>' : "");
  } else {
    const sc = statusClass(cap);
    const sb = cap.stackLabel ? '<span class="stack-badge">' + esc(cap.stackLabel) + '</span>' : "";
    el.innerHTML = '<div class="capture-row1"><span class="cap-type ' + tc + '">' + esc(cap.captureType ? cap.captureType.toUpperCase() : "") + '</span><span class="cap-method">' + esc(cap.method || "") + '</span><span class="cap-status ' + sc + '">' + esc(cap.statusCode || cap.status || "") + '</span><span class="cap-domain">' + esc(cap.domain || getDomain(cap.url || "")) + '</span><span class="cap-time">' + time + '</span></div><div class="cap-url">' + esc(trunc(cap.url || "", 90)) + '</div>' + (cap.duration || cap.stackLabel ? '<div class="cap-row2">' + (cap.duration ? '<span class="cap-duration">' + cap.duration + 'ms</span>' : "") + sb + '</div>' : "");
  }
  el.addEventListener("click", () => showDetail(cap));
  return el;
}

// ── Detail Panel ──────────────────────────────────────────────────────────────
let currentDetailCap = null;

function showDetail(cap) {
  currentDetailCap = cap;
  showOnly(panelDetail);
  const content = document.getElementById("detailContent");
  const tc = "type-" + cap.captureType, sc = statusClass(cap);

  // WebSocket captures get their own full-payload view
  if (cap.captureType === "websocket") {
    var wsHtml = '<div class="detail-section detail-header-row"><div class="detail-badges">'
      + '<span class="detail-badge ' + tc + '">WS</span>'
      + '<span class="detail-badge" style="background:var(--bg3);color:var(--text2)">' + esc((cap.event || "").toUpperCase()) + '</span>'
      + (cap.dir ? '<span class="detail-badge" style="background:var(--bg3);color:var(--text3)">' + esc(cap.dir === "send" ? "↑ SENT" : "↓ RECV") + '</span>' : "")
      + '</div><div class="detail-action-btns"></div></div>';

    if (cap.url) {
      wsHtml += '<div class="detail-section"><div class="detail-label">URL</div><div class="detail-value" style="word-break:break-all">' + esc(cap.url) + '</div></div>';
    }

    if (cap.payload) {
      var wsPayload = cap.payload;
      var wsIsJson = false;
      try { wsPayload = JSON.stringify(JSON.parse(cap.payload), null, 2); wsIsJson = true; } catch(e) {}
      wsHtml += '<div class="detail-section"><div class="detail-label">Payload (' + cap.payload.length + ' chars' + (wsIsJson ? ', JSON' : '') + ')</div>'
        + '<pre class="detail-value" style="white-space:pre-wrap;word-break:break-all;max-height:55vh;overflow-y:auto;font-size:11px;background:var(--bg2);padding:8px;border-radius:4px;margin:0;line-height:1.5">' + esc(wsPayload) + '</pre></div>';
    } else if (cap.event !== "message") {
      wsHtml += '<div class="detail-section"><div class="detail-label">Event</div><div class="detail-value">' + esc(cap.event || "") + (cap.code ? ' (code ' + esc(cap.code) + ')' : '') + (cap.reason ? ' · ' + esc(cap.reason) : '') + '</div></div>';
    }

    var wsMeta = {};
    if (cap.domain) wsMeta.Domain = cap.domain;
    if (cap.wsId) wsMeta['WS Connection'] = cap.wsId;
    if (cap.timestamp) wsMeta.Time = new Date(cap.timestamp).toLocaleTimeString();
    if (Object.keys(wsMeta).length) {
      wsHtml += '<div class="detail-section"><div class="detail-label">Metadata</div><div class="detail-value"><div class="detail-kv">'
        + Object.entries(wsMeta).map(function(kv){ return '<span class="k">' + esc(kv[0]) + '</span><span class="v">' + esc(String(kv[1])) + '</span>'; }).join("")
        + '</div></div></div>';
    }

    content.innerHTML = wsHtml;
    return;
  }

  let html = '<div class="detail-section detail-header-row"><div class="detail-badges">'
    + '<span class="detail-badge ' + tc + '">' + esc(cap.captureType ? cap.captureType.toUpperCase() : "") + '</span>'
    + (cap.method ? '<span class="detail-badge" style="background:var(--bg3);color:var(--text2)">' + esc(cap.method) + '</span>' : "")
    + (cap.statusCode ? '<span class="detail-badge ' + sc + '" style="background:var(--bg3)">' + esc(cap.statusCode) + '</span>' : "")
    + '</div><div class="detail-action-btns">'
    + '<button class="btn-trace" id="btnStartTrace">&#9650; Trace</button>'
    + ((cap.url && (cap.captureType === "http" || cap.captureType === "xhr" || cap.captureType === "fetch")) ? '<button class="btn-replay" id="btnStartReplay">&#9654; Replay</button>' : "")
    + '</div></div>';

  // Request body analysis
  if (cap.requestBody || cap.requestHeaders) {
    html += renderRequestAnalysis(cap);
  }

  if (cap.stackInfo) {
    const si = cap.stackInfo;
    html += '<div class="stack-callout"><div class="stack-callout-title">&#9670; Stack Detection <span class="confidence-' + si.confidence + '">' + si.confidence.toUpperCase() + '</span></div>'
      + (si.databases.length ? '<div class="stack-row"><span class="stack-key">Database</span><span class="stack-val db-val">' + si.databases.map(esc).join(", ") + '</span></div>' : "")
      + (si.orm ? '<div class="stack-row"><span class="stack-key">ORM</span><span class="stack-val">' + esc(si.orm) + '</span></div>' : "")
      + (si.framework ? '<div class="stack-row"><span class="stack-key">Framework</span><span class="stack-val">' + esc(si.framework) + '</span></div>' : "")
      + (si.cloud ? '<div class="stack-row"><span class="stack-key">Cloud</span><span class="stack-val">' + esc(si.cloud) + '</span></div>' : "")
      + (si.apiStyle ? '<div class="stack-row"><span class="stack-key">API Style</span><span class="stack-val">' + esc(si.apiStyle) + '</span></div>' : "")
      + '<div class="stack-evidence">' + si.evidence.map(function(e){ return '<div class="evidence-item">&#8250; ' + esc(e) + '</div>'; }).join("") + '</div></div>';
  }

  var sections = [
    ["URL", cap.url || cap.src],
    ["Request Headers", cap.requestHeaders ? JSON.stringify(cap.requestHeaders, null, 2) : null],
    ["Response Headers", cap.responseHeaders ? JSON.stringify(cap.responseHeaders, null, 2) : null],
    ["Response Body", cap.responseBody],
  ];
  for (var si2 = 0; si2 < sections.length; si2++) {
    var label = sections[si2][0], val = sections[si2][1];
    if (!val) continue;
    html += '<div class="detail-section"><div class="detail-label">' + label + '</div><div class="detail-value">' + esc(typeof val === "string" ? val : JSON.stringify(val, null, 2)) + '</div></div>';
  }

  var meta = {};
  if (cap.duration) meta.Duration = cap.duration + "ms";
  if (cap.timestamp) meta.Time = new Date(cap.timestamp).toLocaleTimeString();
  if (cap.initiator) meta.Initiator = cap.initiator;
  if (cap.type) meta.Type = cap.type;
  if (Object.keys(meta).length) {
    html += '<div class="detail-section"><div class="detail-label">Metadata</div><div class="detail-value"><div class="detail-kv">' + Object.entries(meta).map(function(kv){ return '<span class="k">' + esc(kv[0]) + '</span><span class="v">' + esc(String(kv[1])) + '</span>'; }).join("") + '</div></div></div>';
  }

  content.innerHTML = html;
  document.getElementById("btnStartTrace").addEventListener("click", () => startTrace(cap));
  var replayBtn = document.getElementById("btnStartReplay");
  if (replayBtn) replayBtn.addEventListener("click", () => openReplayPanel(cap));
}

// ── Request Analysis ──────────────────────────────────────────────────────────
function renderRequestAnalysis(cap) {
  const hdrs = cap.requestHeaders || {};
  const body = String(cap.requestBody || "");
  const ct = hdrs["content-type"] || hdrs["Content-Type"] || "";

  let html = '<div class="req-analysis"><div class="req-analysis-title">&#9654; Request Analysis</div>';

  // Auth headers
  var authRows = [];
  for (var k in hdrs) {
    var kl = k.toLowerCase();
    if (kl === "authorization") {
      var v = hdrs[k];
      var tokenType = v.toLowerCase().startsWith("bearer ") ? "Bearer JWT" : v.toLowerCase().startsWith("basic ") ? "Basic Auth" : "Auth";
      authRows.push('<div class="req-field req-field-sensitive"><span class="req-field-key">' + esc(k) + '</span><span class="req-field-badge badge-auth">' + esc(tokenType) + '</span><span class="req-field-val">' + esc(v.slice(0, 60)) + (v.length > 60 ? "\u2026" : "") + '</span></div>');
    } else if (["x-api-key","x-auth-token","x-access-token","x-token","apikey"].indexOf(kl) >= 0) {
      authRows.push('<div class="req-field req-field-sensitive"><span class="req-field-key">' + esc(k) + '</span><span class="req-field-badge badge-auth">API Key</span><span class="req-field-val">' + esc(hdrs[k].slice(0, 60)) + '</span></div>');
    }
  }
  if (authRows.length) html += '<div class="req-section-label">Auth Tokens</div>' + authRows.join("");

  // Cookie header
  if (hdrs["cookie"] || hdrs["Cookie"]) {
    var cookie = hdrs["cookie"] || hdrs["Cookie"];
    var cookiePairs = cookie.split(";").slice(0, 8);
    html += '<div class="req-section-label">Cookies (' + cookiePairs.length + ')</div>';
    for (var ci = 0; ci < cookiePairs.length; ci++) {
      var parts = cookiePairs[ci].trim().split("=");
      var cKey = parts[0] || "";
      var cVal = parts.slice(1).join("=") || "";
      var isSens = isSensitiveKey(cKey);
      html += '<div class="req-field' + (isSens ? " req-field-sensitive" : "") + '"><span class="req-field-key">' + esc(cKey) + '</span>' + (isSens ? '<span class="req-field-badge badge-sensitive">sensitive</span>' : '') + '<span class="req-field-val">' + esc(cVal.slice(0, 50)) + '</span></div>';
    }
  }

  // Body
  if (body) {
    html += '<div class="req-section-label">Body (' + esc(ct || "raw") + ')</div>';
    var fields = [];
    if (ct.includes("json") || body.trim().startsWith("{") || body.trim().startsWith("[")) {
      try {
        var parsed = JSON.parse(body);
        fields = flattenForUI(parsed, "", 0);
      } catch(e) { fields = [{ key: "raw", val: body.slice(0, 200), sens: false }]; }
    } else if (body.includes("=") && !body.trim().startsWith("<")) {
      try {
        var sp = body.split("&");
        for (var fi = 0; fi < sp.length; fi++) {
          var pair = sp[fi].split("=");
          fields.push({ key: decodeURIComponent(pair[0] || ""), val: decodeURIComponent(pair.slice(1).join("=") || ""), sens: isSensitiveKey(pair[0] || "") });
        }
      } catch(e2) { fields = [{ key: "body", val: body.slice(0, 200), sens: false }]; }
    } else {
      fields = [{ key: "body", val: body.slice(0, 300), sens: false }];
    }
    for (var fj = 0; fj < fields.length; fj++) {
      var f = fields[fj];
      html += '<div class="req-field' + (f.sens ? " req-field-sensitive" : "") + '"><span class="req-field-key">' + esc(f.key) + '</span>' + (f.sens ? '<span class="req-field-badge badge-sensitive">&#9888;</span>' : '') + '<span class="req-field-val">' + esc(String(f.val).slice(0, 80)) + '</span></div>';
    }
  }

  html += '</div>';
  return html;
}

function flattenForUI(obj, prefix, depth) {
  var out = [];
  if (!obj || typeof obj !== "object" || depth > 4) return out;
  var keys = Object.keys(obj);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var fullKey = prefix ? prefix + "." + k : k;
    var v = obj[k];
    if (v && typeof v === "object" && !Array.isArray(v)) {
      out = out.concat(flattenForUI(v, fullKey, depth + 1));
    } else {
      out.push({ key: fullKey, val: String(v === null ? "null" : v).slice(0, 200), sens: isSensitiveKey(k) });
    }
  }
  return out;
}

function isSensitiveKey(k) {
  var kl = String(k || "").toLowerCase();
  var sens = ["password","passwd","pass","secret","token","key","api_key","apikey","auth",
    "private","credential","session","jwt","ssn","card","cvv","pin","hash","salt","hmac"];
  for (var i = 0; i < sens.length; i++) { if (kl.indexOf(sens[i]) >= 0) return true; }
  return false;
}

// ── Trace ─────────────────────────────────────────────────────────────────────
let activeTraceId = null, traceLogs = [], traceReport = null;

function startTrace(cap) {
  const traceId = "trace-" + Date.now();
  activeTraceId = traceId; traceLogs = []; traceReport = null;
  showOnly(panelTrace);
  document.getElementById("traceUrl").textContent = trunc(cap.url || cap.domain || "unknown", 70);
  document.getElementById("traceLog").innerHTML = "";
  document.getElementById("traceResult").innerHTML = "";
  document.getElementById("traceResult").classList.add("hidden");
  document.getElementById("traceSpinner").style.display = "flex";
  // FIX: Use the tab that originated the capture, not "active tab" which may be DevTools
  chrome.runtime.sendMessage({ type: "TRACE_REQUEST", capture: cap, traceId, tabId: cap.tabId || null });
}

function appendLog(logEl, entry) {
  var icons = { info:"›", ok:"✓", warn:"⚠", critical:"⚡", probe:"◉", done:"■" };
  var el = document.createElement("div");
  el.className = "tlog tlog-" + entry.level;
  el.innerHTML = '<span class="tlog-icon">' + (icons[entry.level] || "·") + '</span><span class="tlog-text">' + esc(entry.text) + '</span>';
  if (entry.data && (entry.level === "critical" || entry.level === "warn")) {
    var pre = document.createElement("pre");
    pre.className = "tlog-data";
    pre.textContent = JSON.stringify(entry.data, null, 2).slice(0, 400);
    el.appendChild(pre);
  }
  logEl.appendChild(el);
  logEl.scrollTop = logEl.scrollHeight;
}

function listenForTrace() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TRACE_LOG" && msg.entry.traceId === activeTraceId) {
      var log = document.getElementById("traceLog");
      if (log) appendLog(log, msg.entry);
      traceLogs.push(msg.entry);
    }
    if (msg.type === "TRACE_DONE" && msg.traceId === activeTraceId) {
      traceReport = msg.report;
      document.getElementById("traceSpinner").style.display = "none";
      renderTraceReport(msg.report);
    }
  });
}

function renderGameIntelCard(gi) {
  if (!gi) return "";

  // Helper: interpret a field value from the raw responses
  function gv(obj, keys) {
    if (!obj) return null;
    for (var i = 0; i < keys.length; i++) {
      if (obj[keys[i]] !== undefined && obj[keys[i]] !== null) return obj[keys[i]];
    }
    return null;
  }

  var cw = gi.currentWin || gi.rawResponses && (gi.rawResponses.GetCurrentWin || gi.rawResponses.GetLastResult || gi.rawResponses.GetResult || gi.rawResponses.GetRoundResult || gi.rawResponses.GetGameResult);
  var ag = gi.activeGame || gi.rawResponses && (gi.rawResponses.GetActiveGame || gi.rawResponses.GetCurrentGame || gi.rawResponses.GetGameState);

  var cf  = cw && gv(cw, ["CF","cf","Coefficient","multiplier","Multiplier"]);
  var bs  = cw && gv(cw, ["BS","bs","BetSize","betSize","Bet"]) || gi.betSize;
  var ab  = cw && gv(cw, ["AB","ab","AccountBalance","balance","Balance"]);
  var sw  = cw && gv(cw, ["SW","sw","SessionWallet","sessionWallet","SessionBalance"]);
  var sb  = cw && gv(cw, ["SB","sb","SpinBalance","spinBalance"]);
  var an  = cw && gv(cw, ["AN","an","AnimationNumber"]);
  var rsf = cw && gv(cw, ["RS.F","rsf","ResultField","results","Results","RSF"]);
  var rsuc = cw && gv(cw, ["RS.UC","rsuc","ResultUnclaimed","unclaimedCount"]);

  // Compute win amount: bs * cf
  var winAmt = (cf && bs) ? (parseFloat(cf) * parseFloat(bs)).toFixed(2) : null;

  // Build result grid from RS.F
  var gridHtml = "";
  if (rsf !== null && rsf !== undefined) {
    var rsArr = Array.isArray(rsf) ? rsf : String(rsf).split(",");
    var hits = 0;
    var cells = rsArr.map(function(v) {
      var win = (v === true || v === "true");
      if (win) hits++;
      return '<span class="gi-cell ' + (win ? "gi-win" : "gi-loss") + '">' + (win ? "✓" : "✗") + '</span>';
    });
    gridHtml = '<div class="gi-grid-label">Result grid (' + hits + '/' + rsArr.length + ' wins)</div>'
      + '<div class="gi-grid">' + cells.join("") + '</div>';
  }

  // Active game state summary
  var agSummary = "";
  if (ag) {
    var agBs  = gv(ag, ["BS","bs","BetSize"]);
    var agGt  = gv(ag, ["GT","gt","GameType"]);
    var agAct = gv(ag, ["Active","active","IsActive","isActive"]);
    var agParts = [];
    if (agAct !== null && agAct !== undefined) agParts.push("Active: " + (agAct ? "YES" : "NO"));
    if (agGt)  agParts.push("Type: " + agGt);
    if (agBs)  agParts.push("Bet: " + agBs);
    if (agParts.length) agSummary = '<div class="gi-row"><span class="gi-key">Game state</span><span class="gi-val">' + esc(agParts.join(" · ")) + '</span></div>';
  }

  // Endpoint status dots
  var epDots = gi.endpoints.map(function(e) {
    return '<span class="gi-ep ' + (e.hasData ? "gi-ep-ok" : (e.status === 200 ? "gi-ep-warn" : "gi-ep-none")) + '" title="' + esc(e.name) + ' → ' + e.status + '">' + esc(e.name.replace("Get","")) + '</span>';
  }).join("");

  var h = '<div class="gi-card">';
  h += '<div class="gi-header">';
  h += '<span class="gi-game-icon">🎮</span>';
  h += '<span class="gi-game-name">' + esc(gi.gameName.toUpperCase()) + '</span>';
  h += '<span class="gi-game-sub">Game Intelligence</span>';
  h += '</div>';

  if (!cw && !ag) {
    h += '<div class="gi-no-data">No active round found — place a bet first, then press Trace to capture the full result.</div>';
  } else {
    h += '<div class="gi-rows">';

    if (agSummary) h += agSummary;
    if (gi.accountId) h += '<div class="gi-row"><span class="gi-key">Account</span><span class="gi-val">' + esc(String(gi.accountId)) + '</span></div>';
    if (bs)  h += '<div class="gi-row"><span class="gi-key">Bet size</span><span class="gi-val gi-num">' + esc(String(bs)) + '</span></div>';
    if (cf)  h += '<div class="gi-row"><span class="gi-key">Multiplier</span><span class="gi-val gi-cf ' + (parseFloat(cf) >= 2 ? "gi-cf-big" : "") + '">' + esc(String(cf)) + 'x</span></div>';
    if (winAmt) h += '<div class="gi-row"><span class="gi-key">Win amount</span><span class="gi-val gi-win-amt">' + esc(winAmt) + '</span></div>';
    if (sb !== null && sb !== undefined)  h += '<div class="gi-row"><span class="gi-key">Spin balance</span><span class="gi-val">' + esc(String(sb)) + '</span></div>';
    if (sw !== null && sw !== undefined)  h += '<div class="gi-row"><span class="gi-key">Session wallet</span><span class="gi-val">' + esc(String(sw)) + '</span></div>';
    if (ab !== null && ab !== undefined)  h += '<div class="gi-row"><span class="gi-key">Balance</span><span class="gi-val">' + esc(String(ab)) + '</span></div>';
    if (rsuc !== null && rsuc !== undefined) h += '<div class="gi-row"><span class="gi-key">Unclaimed</span><span class="gi-val">' + esc(String(rsuc)) + '</span></div>';
    if (an !== null && an !== undefined)  h += '<div class="gi-row"><span class="gi-key">Animation #</span><span class="gi-val">' + esc(String(an)) + '</span></div>';

    h += '</div>';
    if (gridHtml) h += gridHtml;

    // Raw data accordion for each responded endpoint
    var rawKeys = Object.keys(gi.rawResponses || {}).filter(function(k){ return !k.endsWith("_raw"); });
    if (rawKeys.length) {
      h += '<div class="gi-raw-toggle" onclick="this.nextElementSibling.classList.toggle(\'open\')">▸ Raw endpoint data (' + rawKeys.length + ')</div>';
      h += '<div class="gi-raw-body">';
      rawKeys.forEach(function(k) {
        h += '<div class="gi-raw-ep">' + esc(k) + '</div>';
        h += '<div class="trace-full-resp-body">' + esc(JSON.stringify(gi.rawResponses[k], null, 2).slice(0, 2000)) + '</div>';
      });
      h += '</div>';
    }
  }

  if (epDots) h += '<div class="gi-ep-row">' + epDots + '</div>';
  h += '</div>';
  return h;
}

function renderTraceReport(report) {
  var el = document.getElementById("traceResult");
  el.classList.remove("hidden");

  var html = '';

  // ── Game Intel card (shown first if this is a game request) ──
  if (report.gameIntel) html += renderGameIntelCard(report.gameIntel);

  html += '<div class="trace-summary">';
  if (report.databases && report.databases.length) html += '<span class="tbadge tbadge-db">DB: ' + report.databases.slice(0,3).map(esc).join(", ") + '</span>';
  if (report.frameworks && report.frameworks.length) html += '<span class="tbadge tbadge-fw">Server: ' + report.frameworks.slice(0,2).map(esc).join(", ") + '</span>';
  if (report.clouds && report.clouds.length) html += '<span class="tbadge tbadge-cloud">Cloud: ' + report.clouds.slice(0,2).map(esc).join(", ") + '</span>';
  if (report.orms && report.orms.length) html += '<span class="tbadge tbadge-orm">ORM: ' + report.orms.slice(0,2).map(esc).join(", ") + '</span>';
  if (report.apiStyles && report.apiStyles.length) html += '<span class="tbadge tbadge-api">API: ' + report.apiStyles.slice(0,2).map(esc).join(", ") + '</span>';
  if (report.cdnLayer) html += '<span class="tbadge ' + (report.cdnBypassed ? "tbadge-ok" : "tbadge-warn") + '">CDN: ' + esc(report.cdnLayer) + (report.cdnBypassed ? " \u2713" : "") + '</span>';
  if (report.wafDetected) html += '<span class="tbadge ' + (report.wafBypassed ? "tbadge-ok" : "tbadge-critical") + '">WAF: ' + esc(report.wafDetected) + (report.wafBypassed ? " \u2713 bypassed" : "") + '</span>';
  if (report.originIPs && report.originIPs.length) html += '<span class="tbadge tbadge-ip">IPs: ' + report.originIPs.join(", ") + '</span>';
  if (!report.databases.length && !report.frameworks.length && !report.cdnLayer) html += '<span class="tbadge tbadge-none">No stack detected</span>';
  html += '</div>';

  if (report.geoInfo && report.geoInfo.length) {
    html += '<div class="trace-hosting-box"><div class="trace-hosting-title">&#127757; Server Location</div>';
    for (var gi = 0; gi < report.geoInfo.length; gi++) {
      var g = report.geoInfo[gi];
      html += '<div class="trace-hosting-row"><span class="trace-hosting-key">IP</span><span class="trace-hosting-val">' + esc(g.ip) + '</span></div>';
      if (g.org) html += '<div class="trace-hosting-row"><span class="trace-hosting-key">Hosting</span><span class="trace-hosting-val">' + esc(g.org) + '</span></div>';
      if (g.city || g.country) html += '<div class="trace-hosting-row"><span class="trace-hosting-key">Location</span><span class="trace-hosting-val">' + esc([g.city, g.region, g.country].filter(Boolean).join(", ")) + '</span></div>';
      if (g.asn) html += '<div class="trace-hosting-row"><span class="trace-hosting-key">ASN</span><span class="trace-hosting-val">' + esc(g.asn) + '</span></div>';
    }
    html += '</div>';
  }

  if (report.dnsRecords && report.dnsRecords.length) {
    html += '<div class="trace-section-label">DNS Records</div><div class="trace-evidence-list">';
    for (var di = 0; di < report.dnsRecords.length; di++) html += '<div class="trace-dns-row"><span class="trace-dns-type">' + esc(report.dnsRecords[di].type) + '</span><span class="trace-dns-val">' + esc(report.dnsRecords[di].value) + '</span></div>';
    html += '</div>';
  }

  if (report.severity && report.severity.length || report.jwtFound || report.dataFields && report.dataFields.length) {
    html += '<div class="trace-critical-box"><div class="trace-section-label" style="border:none;padding:0;margin-bottom:4px;color:var(--red)">&#9889; Critical Findings</div>';
    if (report.severity) for (var ci = 0; ci < report.severity.length; ci++) html += '<div class="trace-critical-item">\u26a0 ' + esc(report.severity[ci]) + '</div>';
    if (report.jwtFound) html += '<div class="trace-critical-item">JWT Exposed<pre class="trace-pre">' + esc(JSON.stringify(report.jwtFound.payload || report.jwtFound, null, 2).slice(0, 400)) + '</pre></div>';
    if (report.dataFields) for (var df = 0; df < Math.min(report.dataFields.length, 10); df++) html += '<div class="trace-critical-item">\u26a0 ' + esc(report.dataFields[df]) + '</div>';
    html += '</div>';
  }

  if (report.proxyChain && report.proxyChain.length) {
    html += '<div class="trace-section-label">Proxy Chain</div><div class="trace-proxy-chain">';
    for (var pi = 0; pi < report.proxyChain.length; pi++) { if (pi > 0) html += '<span class="trace-proxy-arrow">\u2192</span>'; html += '<span class="trace-proxy-hop">' + esc(report.proxyChain[pi]) + '</span>'; }
    html += '</div>';
  }

  if (report.thirdPartyChain && report.thirdPartyChain.length) {
    html += '<div class="trace-section-label">Third-Party Route</div>';
    for (var ti = 0; ti < report.thirdPartyChain.length; ti++) {
      var h = report.thirdPartyChain[ti];
      html += '<div class="trace-tp-item"><span class="trace-tp-from">' + esc(h.from) + '</span><span class="trace-chain-arrow">\u2192</span><span class="trace-tp-to">' + esc(h.to) + '</span><span class="trace-tp-via">' + esc(h.via) + '</span></div>';
    }
  }

  if (report.angieBypass && report.angieBypass.attempted) {
    const ab = report.angieBypass;
    html += '<div class="trace-section-label" style="color:' + (ab.found ? 'var(--red)' : 'var(--green)') + '">'
      + (ab.found ? '⚡ Angie Bypass: FOUND' : '✓ Angie Proxy: Hardened') + '</div>';
    if (ab.originDirect) {
      html += '<div class="trace-critical-item">Direct backend IP: <strong>' + esc(ab.originDirect) + '</strong></div>';
    }
    if (ab.findings && ab.findings.length) {
      html += '<div class="trace-evidence-list">';
      for (var ai = 0; ai < ab.findings.length; ai++) {
        var af = ab.findings[ai];
        var label = af.type === "status-page" ? "Status page: " + esc(af.path)
          : af.type === "direct-ip" ? "Direct IP " + esc(af.ip) + " → " + af.status + (af.server ? " [" + esc(af.server) + "]" : "")
          : af.type === "origin-subdomain" ? "Origin subdomain: " + esc(af.url)
          : af.type === "cache-bypass" ? "Cache bypass: different upstream response"
          : af.type === "host-override" ? "Host override '" + esc(af.host) + "' → " + af.status
          : esc(JSON.stringify(af));
        html += '<div class="trace-dns-row"><span class="trace-dns-type">' + esc(af.type) + '</span><span class="trace-dns-val">' + label + '</span></div>';
        if (af.body) html += '<pre class="trace-pre">' + esc(af.body.slice(0,400)) + '</pre>';
      }
      html += '</div>';
    }
  }

  if (report.chain && report.chain.length) {
    html += '<div class="trace-section-label">Redirect Chain</div>';
    for (var ri = 0; ri < report.chain.length; ri++) html += '<div class="trace-chain-item"><span class="trace-chain-from">' + esc(trunc(report.chain[ri].from, 42)) + '</span><span class="trace-chain-arrow">\u2192</span><span class="trace-chain-to">' + esc(trunc(report.chain[ri].to, 42)) + '</span></div>';
  }

  if (report.fullResponses && report.fullResponses.length) {
    html += '<div class="trace-section-label">Full Responses (' + report.fullResponses.length + ')</div>';
    for (var fri = 0; fri < report.fullResponses.length; fri++) {
      var fr = report.fullResponses[fri];
      var fsc = !fr.status ? "" : fr.status < 300 ? "tok" : fr.status < 400 ? "twarn" : "terr";
      html += '<div class="trace-full-resp"><div class="trace-full-resp-head" onclick="this.nextElementSibling.classList.toggle(\'open\');this.nextElementSibling.nextElementSibling.classList.toggle(\'open\')"><span class="trace-full-resp-label">' + esc(fr.label) + ': ' + esc(trunc(fr.url, 50)) + '</span>' + (fr.status ? '<span class="trace-full-resp-status ' + fsc + '">' + fr.status + '</span>' : "") + '</div><div class="trace-full-resp-hdrs open">' + Object.entries(fr.headers || {}).map(function(kv){ return '<div><span style="color:var(--accent)">' + esc(kv[0]) + ':</span> ' + esc(kv[1]) + '</div>'; }).join("") + '</div><div class="trace-full-resp-body">' + esc(fr.body || "(empty)") + '</div></div>';
    }
  }

  var sigProbes = (report.probes || []).filter(function(p){ return p.findings && p.findings.length && p.status !== 404; });
  if (sigProbes.length) {
    html += '<div class="trace-section-label">Probe Results (' + sigProbes.length + ')</div>';
    for (var pri = 0; pri < sigProbes.length; pri++) {
      var p = sigProbes[pri];
      var psc = !p.status ? "" : p.status < 300 ? "tok" : p.status < 400 ? "twarn" : "terr";
      html += '<div class="trace-probe"><div class="trace-probe-head"><span class="trace-probe-label">' + esc(p.label) + '</span>' + (p.status ? '<span class="trace-probe-status ' + psc + '">' + p.status + '</span>' : "") + '</div>' + p.findings.slice(0, 8).map(function(f){ return '<div class="trace-probe-finding">' + esc(f) + '</div>'; }).join("") + '</div>';
    }
  }

  if (report.evidence && report.evidence.length) {
    html += '<div class="trace-section-label">Evidence</div><div class="trace-evidence-list">' + [...new Set(report.evidence)].slice(0, 25).map(function(e){ return '<div class="trace-evidence-item">\u203a ' + esc(e) + '</div>'; }).join("") + '</div>';
  }

  // Deep analysis sections
  if (report.deepAnalysis) {
    var da = report.deepAnalysis;

    if (da.serverTiming && da.serverTiming.length) {
      html += '<div class="trace-section-label">&#9201; Server-Timing (backend ops)</div><div class="trace-evidence-list">';
      da.serverTiming.forEach(function(t) {
        var bar = t.dur !== null ? '<span style="display:inline-block;width:'+Math.min(Math.round(t.dur*1.5),120)+'px;height:3px;background:var(--accent);border-radius:2px;margin-left:6px;vertical-align:middle"></span>' : '';
        html += '<div class="trace-dns-row"><span class="trace-dns-type">'+esc(t.name)+'</span><span class="trace-dns-val">'+(t.dur!==null?t.dur+'ms':'-')+bar+(t.desc?' — '+esc(t.desc):'')+' '+(t.dur>200?'<span style="color:var(--red)">&#9888; slow</span>':'')+'</span></div>';
      });
      html += '</div>';
    }

    if (da.authMechanisms && da.authMechanisms.length) {
      html += '<div class="trace-section-label">&#128273; Auth Mechanisms</div><div class="trace-evidence-list">';
      da.authMechanisms.forEach(function(a) {
        html += '<div class="trace-dns-row"><span class="trace-dns-type">'+esc(a.type)+'</span><span class="trace-dns-val">'+esc(a.value||''+(a.algs?a.algs.join(','):'')||(a.cookieCount?a.cookieCount+' cookies':''))+'</span></div>';
      });
      html += '</div>';
    }

    if (da.authTokens && da.authTokens.length) {
      html += '<div class="trace-critical-box"><div class="trace-section-label" style="border:none;padding:0;margin-bottom:4px;color:var(--red)">&#128274; JWT Tokens Found ('+da.authTokens.length+')</div>';
      da.authTokens.forEach(function(j) {
        html += '<div class="trace-critical-item"><strong>alg: '+esc(j.header.alg||'?')+'</strong>';
        if (j.payload.sub||j.payload.user_id||j.payload.id) html += ' &nbsp; sub: '+esc(String(j.payload.sub||j.payload.user_id||j.payload.id||''));
        if (j.payload.exp) html += ' &nbsp; exp: '+esc(new Date(j.payload.exp*1000).toISOString());
        if (j.payload.iat) html += ' &nbsp; iat: '+esc(new Date(j.payload.iat*1000).toISOString());
        html += '<pre class="trace-pre">'+esc(JSON.stringify(j.payload,null,2).slice(0,600))+'</pre></div>';
      });
      html += '</div>';
    }

    var sensC = (da.cookies||[]).filter(function(c){return c.sensitive;});
    var normC = (da.cookies||[]).filter(function(c){return !c.sensitive;});
    if (sensC.length) {
      html += '<div class="trace-critical-box"><div class="trace-section-label" style="border:none;padding:0;margin-bottom:4px;color:var(--red)">&#127850; Sensitive Cookies</div>';
      sensC.forEach(function(c) {
        html += '<div class="trace-critical-item"><strong>'+esc(c.name)+'</strong> ['+esc(c.source)+'] = '+esc((c.val||'').slice(0,80))+(c.attrs&&c.attrs.httponly?'':' <span style="color:var(--red)">&#9888; no HttpOnly</span>')+(c.attrs&&c.attrs.secure?'':' <span style="color:var(--red)">&#9888; no Secure</span>')+'</div>';
      });
      html += '</div>';
    }
    if (normC.length) {
      html += '<div class="trace-section-label">Cookies ('+normC.length+')</div><div class="trace-evidence-list">';
      normC.slice(0,10).forEach(function(c){ html += '<div class="trace-dns-row"><span class="trace-dns-type">'+esc(c.name)+'</span><span class="trace-dns-val">'+esc((c.val||'').slice(0,80))+' ['+esc(c.source)+']</span></div>'; });
      html += '</div>';
    }

    if (da.sensitiveFields && da.sensitiveFields.length) {
      html += '<div class="trace-critical-box"><div class="trace-section-label" style="border:none;padding:0;margin-bottom:4px;color:var(--red)">&#9888; Sensitive Payload Fields</div>';
      da.sensitiveFields.forEach(function(f){ html += '<div class="trace-critical-item">['+esc(f.source)+'] <strong>'+esc(f.key)+'</strong>: '+esc(f.hint)+'</div>'; });
      html += '</div>';
    }

    if (da.requestPayload) {
      html += '<div class="trace-section-label">&#128228; Request Payload ('+esc(da.requestPayload.contentType||'raw')+', '+(da.requestPayload.raw||'').length+' bytes)</div>';
      var rp = da.requestPayload.parsed;
      if (rp && typeof rp==='object') {
        html += '<div class="trace-evidence-list">';
        var flat = flattenForUI(rp,'',0);
        flat.slice(0,40).forEach(function(f2){ html += '<div class="trace-dns-row'+(f2.sens?'" style="background:rgba(255,80,80,0.08)':'')+'">'+'<span class="trace-dns-type">'+esc(f2.key)+'</span><span class="trace-dns-val">'+esc(String(f2.val).slice(0,120))+(f2.sens?' &#9888;':'')+'</span></div>'; });
        if (flat.length>40) html += '<div style="color:var(--text3);font-size:10px;padding:2px 8px">…'+(flat.length-40)+' more fields</div>';
        html += '</div>';
      } else { html += '<pre class="trace-pre">'+esc((da.requestPayload.raw||'').slice(0,800))+'</pre>'; }
    }

    if (da.responsePayload) {
      html += '<div class="trace-section-label">&#128229; Response Payload ('+esc(da.responsePayload.contentType||'raw')+', '+da.responsePayload.size+' bytes)</div>';
      var rp2 = da.responsePayload.parsed;
      if (rp2 && typeof rp2==='object') {
        html += '<div class="trace-evidence-list">';
        var flat2 = flattenForUI(rp2,'',0);
        flat2.slice(0,60).forEach(function(f3){ html += '<div class="trace-dns-row'+(f3.sens?'" style="background:rgba(255,80,80,0.08)':'')+'">'+'<span class="trace-dns-type">'+esc(f3.key)+'</span><span class="trace-dns-val">'+esc(String(f3.val).slice(0,160))+(f3.sens?' &#9888;':'')+'</span></div>'; });
        if (flat2.length>60) html += '<div style="color:var(--text3);font-size:10px;padding:2px 8px">…'+(flat2.length-60)+' more fields</div>';
        html += '</div>';
      } else { html += '<pre class="trace-pre">'+esc((da.responsePayload.raw||'').slice(0,1500))+'</pre>'; }
    }
  }

  html += '<div style="padding:8px 0"><button class="btn-trace-export" id="btnExportTrace">&#8595; Export Full Trace JSON</button></div>';
  el.innerHTML = html;

  document.getElementById("btnExportTrace").addEventListener("click", function() {
    dl(new Blob([JSON.stringify({ report: traceReport, logs: traceLogs }, null, 2)], { type: "application/json" }), "lp-trace-" + Date.now() + ".json");
  });
}

// ── Replay ────────────────────────────────────────────────────────────────────
let activeReplayId = null, replayLogs = [], currentReplayCap = null;

function openReplayPanel(cap) {
  currentReplayCap = cap;
  activeReplayId = null;
  showOnly(panelReplay);
  document.getElementById("replayUrl").textContent = trunc(cap.url || "", 70);
  document.getElementById("replayMethod").value = cap.method || "GET";
  document.getElementById("replayUrlInput").value = cap.url || "";
  document.getElementById("replayBody").value = cap.requestBody || "";
  document.getElementById("replayHeaders").value = "";
  document.getElementById("replayLog").innerHTML = "";
  document.getElementById("replayResult").innerHTML = "";
  document.getElementById("replayResult").classList.add("hidden");
  document.getElementById("replaySpinner").style.display = "none";

  var analysisEl = document.getElementById("replayResult");
  analysisEl.classList.remove("hidden");
  analysisEl.innerHTML = renderPreAnalysis(cap);
}

function renderPreAnalysis(cap) {
  var html = '<div class="replay-analysis"><div class="replay-analysis-title">&#128269; What Was Sent</div>';
  html += '<div class="req-analysis">' + renderRequestAnalysis(cap) + '</div>';
  if (cap.statusCode >= 400) html += '<div class="replay-hint"><b>Original got ' + cap.statusCode + '</b> — Replay will try ' + REPLAY_BYPASS_COUNT + ' bypass variants automatically.</div>';
  else html += '<div class="replay-hint">Original got ' + (cap.statusCode || "?") + ' — Replay will clone this request exactly, then try bypass variants if needed.</div>';
  html += '</div>';
  return html;
}
var REPLAY_BYPASS_COUNT = 7;

function fireReplay(cap, overrides) {
  const replayId = "replay-" + Date.now();
  activeReplayId = replayId;
  replayLogs = [];

  document.getElementById("replayLog").innerHTML = "";
  document.getElementById("replayResult").innerHTML = "";
  document.getElementById("replayResult").classList.add("hidden");
  document.getElementById("replaySpinner").style.display = "flex";

  // FIX: Use capture's originating tab, not "active tab" which may be DevTools
  chrome.runtime.sendMessage({
    type: "REPLAY_REQUEST",
    capture: cap,
    replayId,
    tabId: cap.tabId || null,
    overrides,
  });
}

function listenForReplay() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "REPLAY_LOG" && msg.entry.replayId === activeReplayId) {
      var log = document.getElementById("replayLog");
      if (log) appendLog(log, msg.entry);
      replayLogs.push(msg.entry);
    }
    if (msg.type === "REPLAY_DONE" && msg.replayId === activeReplayId) {
      document.getElementById("replaySpinner").style.display = "none";
      renderReplayResult(msg.result);
    }
  });
}

function renderReplayResult(result) {
  var el = document.getElementById("replayResult");
  el.classList.remove("hidden");

  var sc = result.finalStatus;
  var scClass = !sc ? "terr" : sc < 300 ? "tok" : sc < 400 ? "twarn" : "terr";
  var scLabel = !sc ? "No response" : sc < 300 ? "SUCCESS" : sc < 400 ? "Redirect" : sc < 500 ? "Client Error" : "Server Error";

  var html = '<div class="replay-result-header">';
  html += '<span class="replay-status-badge ' + scClass + '">' + (sc || "ERR") + ' ' + scLabel + '</span>';
  if (result.timing) html += '<span class="replay-timing">' + result.timing + 'ms</span>';
  if (result.successAttempt) html += '<span class="replay-attempt-badge">Attempt ' + result.successAttempt + (result.bypassUsed ? " (bypass)" : " (exact clone)") + '</span>';
  html += '</div>';

  if (result.bypassUsed) {
    html += '<div class="replay-bypass-used"><b>Bypass headers used:</b> ' + Object.entries(result.bypassUsed).map(function(kv){ return esc(kv[0]) + ': ' + esc(kv[1]); }).join(", ") + '</div>';
  }

  if (result.attempts && result.attempts.length) {
    html += '<div class="replay-section-label">Attempt Summary</div><div class="replay-attempts">';
    for (var ai = 0; ai < result.attempts.length; ai++) {
      var att = result.attempts[ai];
      var asc = !att.status ? "terr" : att.status < 300 ? "tok" : att.status < 400 ? "twarn" : "terr";
      html += '<div class="replay-attempt-row"><span class="replay-attempt-num">#' + att.attempt + '</span><span class="replay-probe-status ' + asc + '">' + (att.status || att.error || "err") + '</span><span class="replay-attempt-label">' + esc(att.label) + '</span>' + (att.timing ? '<span class="replay-attempt-timing">' + att.timing + 'ms</span>' : "") + '</div>';
    }
    html += '</div>';
  }

  if (result.finalHeaders && Object.keys(result.finalHeaders).length) {
    html += '<div class="replay-section-label">Response Headers</div><div class="replay-resp-headers">';
    var hdrEntries = Object.entries(result.finalHeaders);
    for (var hi = 0; hi < hdrEntries.length; hi++) {
      html += '<div class="replay-hdr-row"><span class="replay-hdr-key">' + esc(hdrEntries[hi][0]) + '</span><span class="replay-hdr-val">' + esc(hdrEntries[hi][1]) + '</span></div>';
    }
    html += '</div>';
  }

  if (result.finalBody) {
    var body = result.finalBody;
    var prettyBody = body;
    try { prettyBody = JSON.stringify(JSON.parse(body), null, 2); } catch(e) {}
    html += '<div class="replay-section-label">Response Body (' + body.length + ' bytes) <button class="btn-copy-body" id="btnCopyBody">&#128203; Copy</button></div>';
    html += '<pre class="replay-body-content" id="replayBodyContent">' + esc(prettyBody.slice(0, 12000)) + (prettyBody.length > 12000 ? "\n\u2026 truncated" : "") + '</pre>';
  }

  if (result.redirectChain && result.redirectChain.length) {
    html += '<div class="replay-section-label">Redirect Chain</div>';
    for (var rci = 0; rci < result.redirectChain.length; rci++) {
      html += '<div class="trace-chain-item"><span class="trace-chain-from">' + esc(trunc(result.redirectChain[rci].from, 45)) + '</span><span class="trace-chain-arrow">\u2192</span><span class="trace-chain-to">' + esc(trunc(result.redirectChain[rci].to, 45)) + '</span></div>';
    }
  }

  html += '<div style="padding:8px 0;display:flex;gap:8px"><button class="btn-trace-export" id="btnExportReplay">&#8595; Export Replay JSON</button><button class="btn-trace-export" id="btnReRunReplay">&#9654; Re-run</button></div>';
  el.innerHTML = html;

  document.getElementById("btnCopyBody") && document.getElementById("btnCopyBody").addEventListener("click", function() {
    var bodyEl = document.getElementById("replayBodyContent");
    if (bodyEl) { try { navigator.clipboard.writeText(bodyEl.textContent); } catch(e2) {} }
  });
  document.getElementById("btnExportReplay").addEventListener("click", function() {
    dl(new Blob([JSON.stringify({ result: result, logs: replayLogs }, null, 2)], { type: "application/json" }), "lp-replay-" + Date.now() + ".json");
  });
  document.getElementById("btnReRunReplay").addEventListener("click", function() {
    if (currentReplayCap) openReplayPanel(currentReplayCap);
  });
}

// ── Live Intel (auto-probe from MakeBet) ─────────────────────────────────────
function loadLiveIntel() {
  chrome.runtime.sendMessage({ type: "GET_LIVE_INTEL" }, (resp) => {
    if (resp && resp.intel) renderLiveIntelBanner(resp.intel);
  });
}

function listenForLiveIntel() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "LIVE_INTEL") renderLiveIntelBanner(msg.intel);
  });
}

function renderLiveIntelBanner(intel) {
  if (!intel || !liveIntelBanner) return;
  liveIntelBanner.classList.remove("hidden");

  // Helper to get value from multiple possible keys
  function gv(obj, keys) {
    if (!obj) return null;
    for (var i = 0; i < keys.length; i++) {
      if (obj[keys[i]] !== undefined && obj[keys[i]] !== null) return obj[keys[i]];
    }
    return null;
  }

  var cw = intel.currentWin ||
    (intel.rawResponses && (intel.rawResponses.GetCurrentWin || intel.rawResponses.GetLastResult));
  var ag = intel.activeGame ||
    (intel.rawResponses && (intel.rawResponses.GetActiveGame || intel.rawResponses.GetCurrentGame));

  var cf    = cw && gv(cw, ["CF","cf","Coefficient","multiplier","Multiplier"]);
  var bs    = cw && gv(cw, ["BS","bs","BetSize","betSize","Bet"]) || intel.betSize;
  var ab    = cw && gv(cw, ["AB","ab","AccountBalance","balance","Balance"]);
  var sw    = cw && gv(cw, ["SW","sw","SessionWallet","sessionWallet","SessionBalance"]);
  var rsf   = cw && gv(cw, ["RS.F","rsf","ResultField","results","Results","RSF"]);
  var rsuc  = cw && gv(cw, ["RS.UC","rsuc","ResultUnclaimed","unclaimedCount"]);
  var an    = cw && gv(cw, ["AN","an","AnimationNumber"]);
  var winAmt = (cf && bs) ? (parseFloat(cf) * parseFloat(bs)).toFixed(2) : null;

  var isProbing = intel.status === "probing";
  var hasData = cw || ag;

  // Build RS.F grid
  var gridHtml = "";
  if (rsf !== null && rsf !== undefined) {
    var rsArr = Array.isArray(rsf) ? rsf : String(rsf).split(",");
    var hits = 0;
    var cells = rsArr.map(function(v) {
      var win = (v === true || v === "true");
      if (win) hits++;
      return '<span class="gi-cell ' + (win ? "gi-win" : "gi-loss") + '">' + (win ? "✓" : "✗") + '</span>';
    });
    gridHtml = '<div class="gi-grid-label">Pre-gen grid (' + hits + '/' + rsArr.length + ' wins)</div>'
      + '<div class="gi-grid">' + cells.join("") + '</div>';
  }

  // Active game summary
  var agHtml = "";
  if (ag) {
    var agBs  = gv(ag, ["BS","bs","BetSize"]);
    var agGt  = gv(ag, ["GT","gt","GameType"]);
    var agAct = gv(ag, ["Active","active","IsActive","isActive"]);
    var parts = [];
    if (agAct !== null && agAct !== undefined) parts.push((agAct ? "✓ ACTIVE" : "○ idle"));
    if (agGt)  parts.push("Type: " + agGt);
    if (agBs)  parts.push("Bet: " + agBs);
    if (parts.length) agHtml = '<div class="li-row"><span class="li-key">Game</span><span class="li-val">' + esc(parts.join(" · ")) + '</span></div>';
  }

  // Endpoint dots
  var epDots = (intel.endpoints || []).map(function(e) {
    var cls = e.hasData ? "gi-ep-ok" : (e.status === 200 ? "gi-ep-warn" : "gi-ep-none");
    return '<span class="gi-ep ' + cls + '" title="' + esc(e.name) + ' → ' + e.status + '">' + esc(e.name.replace("Get","")) + '</span>';
  }).join("");

  var elapsed = intel.capturedAt ? Math.round((Date.now() - intel.capturedAt) / 1000) : 0;

  var h = '<div class="li-header">';
  h += '<span class="li-pulse' + (isProbing ? " li-pulsing" : "") + '">⚡</span>';
  h += '<span class="li-title">LIVE INTEL</span>';
  h += '<span class="li-game">' + esc((intel.gameName || "").toUpperCase()) + '</span>';
  if (isProbing) {
    h += '<span class="li-status li-status-probing">probing…</span>';
  } else {
    h += '<span class="li-status li-status-ready">ready · ' + elapsed + 's ago</span>';
  }
  h += '<button class="li-dismiss" id="liDismiss">✕</button>';
  h += '</div>';

  if (isProbing) {
    h += '<div class="li-probing-row"><span class="spinner-dot" style="background:var(--accent)"></span><span class="spinner-dot" style="background:var(--accent);animation-delay:.2s"></span><span class="spinner-dot" style="background:var(--accent);animation-delay:.4s"></span><span class="li-probe-text">Querying GetCurrentWin…</span></div>';
  } else if (!hasData) {
    h += '<div class="li-no-data">No round data returned — server may need AN. Trace a MakeBet for full context.</div>';
  } else {
    h += '<div class="li-rows">';
    if (agHtml) h += agHtml;
    if (intel.accountId) h += '<div class="li-row"><span class="li-key">Account</span><span class="li-val">' + esc(String(intel.accountId)) + '</span></div>';
    if (bs)  h += '<div class="li-row"><span class="li-key">Bet size</span><span class="li-val li-num">' + esc(String(bs)) + '</span></div>';
    if (cf)  h += '<div class="li-row"><span class="li-key">Multiplier</span><span class="li-val li-cf' + (parseFloat(cf) >= 2 ? " li-cf-big" : "") + '">' + esc(String(cf)) + 'x</span></div>';
    if (winAmt) h += '<div class="li-row"><span class="li-key">Win amount</span><span class="li-val li-win-amt">' + esc(winAmt) + '</span></div>';
    if (sw !== null && sw !== undefined) h += '<div class="li-row"><span class="li-key">Session wallet</span><span class="li-val">' + esc(String(sw)) + '</span></div>';
    if (ab !== null && ab !== undefined) h += '<div class="li-row"><span class="li-key">Balance</span><span class="li-val">' + esc(String(ab)) + '</span></div>';
    if (rsuc !== null && rsuc !== undefined) h += '<div class="li-row"><span class="li-key">Unclaimed</span><span class="li-val">' + esc(String(rsuc)) + '</span></div>';
    if (an !== null && an !== undefined) h += '<div class="li-row"><span class="li-key">Animation #</span><span class="li-val">' + esc(String(an)) + '</span></div>';
    h += '</div>';
    if (gridHtml) h += gridHtml;
  }

  if (epDots) h += '<div class="gi-ep-row">' + epDots + '</div>';

  liveIntelBanner.innerHTML = h;

  // Dismiss button
  var dismissBtn = document.getElementById("liDismiss");
  if (dismissBtn) {
    dismissBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      liveIntelBanner.classList.add("hidden");
      chrome.runtime.sendMessage({ type: "CLEAR_LIVE_INTEL" }).catch(() => {});
    });
  }
}

// ── Live updates ──────────────────────────────────────────────────────────────
function listenForNew() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== "NEW_CAPTURE" || paused) return;
    updateCounters();
    var nets = ["all","http","xhr","fetch","websocket","iframe","dom"];
    if (nets.indexOf(currentTab) < 0) return;
    if (currentTab !== "all" && currentTab !== msg.entry.captureType) return;
    if (searchQuery && JSON.stringify(msg.entry).toLowerCase().indexOf(searchQuery.toLowerCase()) < 0) return;
    captureList.insertBefore(buildCaptureItem(msg.entry), captureList.firstChild);
    allCaptures.unshift(msg.entry);
  });
}

function updateCounters() {
  chrome.runtime.sendMessage({ type: "GET_STATS" }, (s) => {
    if (!s) return;
    totalCounter.textContent = s.total;
    document.getElementById("countAll").textContent    = s.total;
    document.getElementById("countHttp").textContent   = s.http;
    document.getElementById("countXhr").textContent    = s.xhr || 0;
    document.getElementById("countFetch").textContent  = s.fetch || 0;
    document.getElementById("countWs").textContent     = s.websocket;
    document.getElementById("countIframe").textContent = s.iframe;
    document.getElementById("countDom").textContent    = s.dom;
    document.getElementById("countStack").textContent  = s.fingerprintedCount || 0;
  });
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function renderStats(stats) {
  if (!stats) return;
  document.getElementById("statsGrid").innerHTML =
    '<div class="stat-card"><div class="stat-num" style="color:var(--accent)">' + stats.total + '</div><div class="stat-label">Total</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--http)">' + stats.http + '</div><div class="stat-label">HTTP</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--ws)">' + stats.websocket + '</div><div class="stat-label">WS</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--iframe)">' + stats.iframe + '</div><div class="stat-label">iframe</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--dom)">' + stats.dom + '</div><div class="stat-label">DOM</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--red)">' + stats.errorCount + '</div><div class="stat-label">Errors</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--yellow)">' + stats.avgDuration + 'ms</div><div class="stat-label">Avg ms</div></div>' +
    '<div class="stat-card"><div class="stat-num" style="color:var(--db)">' + (stats.fingerprintedCount || 0) + '</div><div class="stat-label">Fingerprinted</div></div>';
  document.getElementById("domainList").innerHTML = (stats.topDomains || []).map(function(d){ return '<li><span>' + esc(d.domain) + '</span><span>' + d.count + '</span></li>'; }).join("");
  document.getElementById("typeList").innerHTML = Object.entries(stats.typeCounts || {}).sort(function(a,b){ return b[1]-a[1]; }).map(function(e){ return '<li><span>' + esc(e[0]) + '</span><span>' + e[1] + '</span></li>'; }).join("");
}

// ── Stack ─────────────────────────────────────────────────────────────────────
function renderStackPanel(caps) {
  if (!caps.length) { panelStack.innerHTML = '<div class="empty-state"><div class="empty-icon">&#128270;</div><div>No stack fingerprints yet</div></div>'; return; }
  var byDomain = {};
  for (var i = 0; i < caps.length; i++) {
    var cap = caps[i];
    var d = cap.domain || "unknown";
    if (!byDomain[d]) byDomain[d] = { domain: d, databases: {}, orms: {}, frameworks: {}, clouds: {}, apiStyles: {}, evidence: [], count: 0 };
    var g = byDomain[d]; g.count++;
    var si = cap.stackInfo;
    (si.databases || []).forEach(function(x){ g.databases[x] = 1; });
    if (si.orm) g.orms[si.orm] = 1;
    if (si.framework) g.frameworks[si.framework] = 1;
    if (si.cloud) g.clouds[si.cloud] = 1;
    if (si.apiStyle) g.apiStyles[si.apiStyle] = 1;
    g.evidence = g.evidence.concat(si.evidence || []);
  }
  panelStack.innerHTML = Object.values(byDomain).sort(function(a,b){ return b.count-a.count; }).map(function(g) {
    var dbs = Object.keys(g.databases);
    var uniqEv = [...new Set(g.evidence)].slice(0, 6);
    return '<div class="stack-card"><div class="stack-card-header"><span class="stack-domain">' + esc(g.domain) + '</span><span class="stack-hit-count">' + g.count + ' hits</span></div>' +
      (dbs.length ? '<div class="stack-section"><span class="stack-section-label">Database</span><span class="stack-db-pills">' + dbs.map(function(d){ return '<span class="db-pill">' + esc(d) + '</span>'; }).join("") + '</span></div>' : "") +
      (Object.keys(g.orms).length ? '<div class="stack-section"><span class="stack-section-label">ORM</span><span class="stack-val">' + Object.keys(g.orms).map(esc).join(", ") + '</span></div>' : "") +
      (Object.keys(g.frameworks).length ? '<div class="stack-section"><span class="stack-section-label">Framework</span><span class="stack-val">' + Object.keys(g.frameworks).map(esc).join(", ") + '</span></div>' : "") +
      (Object.keys(g.clouds).length ? '<div class="stack-section"><span class="stack-section-label">Cloud</span><span class="stack-val">' + Object.keys(g.clouds).map(esc).join(", ") + '</span></div>' : "") +
      (uniqEv.length ? '<div class="evidence-list">' + uniqEv.map(function(e){ return '<div class="evidence-item">&#8250; ' + esc(e) + '</div>'; }).join("") + '</div>' : "") +
      '</div>';
  }).join("");
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function esc(s) { return String(s == null ? "" : s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function trunc(s, n) { s = String(s == null ? "" : s) || ""; return s.length > n ? s.slice(0, n) + "\u2026" : s; }
function getDomain(url) { try { return new URL(url).hostname; } catch(e) { return url; } }
function formatTime(ts) { if (!ts) return ""; return new Date(ts).toLocaleTimeString([], { hour:"2-digit", minute:"2-digit", second:"2-digit" }); }
function dl(blob, name) { var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); }
function statusClass(cap) {
  if (!cap.statusCode) return cap.status === "error" ? "status-error" : "status-pending";
  if (cap.statusCode < 300) return "status-ok";
  if (cap.statusCode < 400) return "status-redirect";
  return "status-error";
}

// ── Execute Panel ──────────────────────────────────────────────────────────────
var _execArmed = false;

function listenForExec() {
  var eCode    = document.getElementById("execCode");
  var eOutput  = document.getElementById("execOutput");
  var eStatus  = document.getElementById("execStatus");
  var eAutoOn  = document.getElementById("execAutoOn");
  var eAutoPat = document.getElementById("execAutoPattern");
  var eArmed   = document.getElementById("execAutoStatus");
  var eTempl   = document.getElementById("execTemplate");

  var TMPLS = {
    "fetch_get":    'fetch("https://example.com/api/data", {\n  method: "GET",\n  credentials: "include"\n});',
    "fetch_post":   'fetch("https://example.com/api/action", {\n  method: "POST",\n  headers: { "content-type": "application/json", "x-auth": "Bearer TOKEN" },\n  body: JSON.stringify({ key: "value" }),\n  credentials: "include"\n});',
    "read_window":  '({\n  keys: Object.keys(window).filter(k => !["chrome","document","window","navigator","location","history","screen","performance","console"].includes(k) && typeof window[k] !== "function").slice(0,40),\n  token: window.token || window.userToken || window.authToken || window.accessToken || null,\n  store: window.__store__ ? JSON.stringify(window.__store__.getState()).slice(0,2000) : null,\n  nextData: window.__NEXT_DATA__ ? JSON.stringify(window.__NEXT_DATA__).slice(0,2000) : null,\n  user: window.currentUser || window.user || window.userData || null\n});',
    "read_storage": '({\n  localStorage: Object.fromEntries(Object.keys(localStorage).map(k=>[k, localStorage.getItem(k).slice(0,200)])),\n  sessionStorage: Object.fromEntries(Object.keys(sessionStorage).map(k=>[k, sessionStorage.getItem(k).slice(0,200)])),\n  cookies: document.cookie\n});',
    "hook_fetch":   '// Hook fetch to spy on all future calls\n(function() {\n  if (window.__lp_hooked) return "already hooked";\n  window.__lp_hooked = true;\n  window.__lp_log = [];\n  const orig = window.fetch;\n  window.fetch = async function(...args) {\n    const res = await orig(...args);\n    const clone = res.clone();\n    const body = await clone.text().catch(()=>"");\n    window.__lp_log.push({ url: args[0], status: res.status, body: body.slice(0,400), ts: Date.now() });\n    if (window.__lp_log.length > 50) window.__lp_log.shift();\n    return res;\n  };\n  return "fetch hooked — run: window.__lp_log";\n})();'
  };

  // Exec tab click — handled here only (setupTabs skips this tab)
  document.getElementById("tabExec").addEventListener("click", function() {
    document.querySelectorAll(".tab").forEach(function(t){ t.classList.remove("active"); });
    this.classList.add("active");
    currentTab = "exec";
    showOnly(document.getElementById("panelExec"));
  });

  document.getElementById("btnExecRun").addEventListener("click", function(){ execRun(eCode, eOutput, eStatus); });
  document.getElementById("btnExecClear").addEventListener("click", function(){
    eCode.value = "";
    eOutput.innerHTML = '<div class="exec-output-empty">Output will appear here</div>';
    eStatus.textContent = "";
  });

  eTempl.addEventListener("change", function(){
    if (TMPLS[this.value]) { eCode.value = TMPLS[this.value]; this.value = ""; }
  });

  eAutoOn.addEventListener("change", function(){
    _execArmed = this.checked;
    if (eArmed) eArmed.classList.toggle("hidden", !_execArmed);
  });

  eCode.addEventListener("keydown", function(e){
    if (e.ctrlKey && e.key === "Enter"){ e.preventDefault(); execRun(eCode, eOutput, eStatus); }
  });

  // Auto-trigger listener
  chrome.runtime.onMessage.addListener(function(msg){
    if (msg.type === "EXEC_AUTO_TRIGGER" && _execArmed){
      var pat = eAutoPat.value.trim();
      if (pat && msg.url && msg.url.includes(pat)){
        eStatus.textContent = "Auto!";
        execRun(eCode, eOutput, eStatus);
      }
    }
  });
}

function execRun(eCode, eOutput, eStatus) {
  var code = eCode.value.trim();
  if (!code) return;
  eStatus.textContent = "Running…";
  eOutput.innerHTML = '<div class="exec-output-empty" style="color:var(--accent)">&#9654; Executing…</div>';

  // FIX: Query all tabs in the current window, then filter out DevTools and
  // extension pages so we always target the real website tab.
  chrome.tabs.query({ currentWindow: true }, function(tabs) {
    if (!tabs || !tabs.length) { execShowErr(eOutput, eStatus, "No tabs found"); return; }

    // Prefer the active non-devtools tab; fall back to first real tab
    var realTabs = tabs.filter(function(t) {
      var url = t.url || "";
      return !url.startsWith("devtools://")
          && !url.startsWith("chrome-extension://")
          && !url.startsWith("chrome://")
          && !url.startsWith("about:");
    });
    var target = realTabs.find(function(t){ return t.active; }) || realTabs[0];

    if (!target) { execShowErr(eOutput, eStatus, "No accessible tab found"); return; }

    chrome.runtime.sendMessage({ type: "EXEC_SCRIPT", code: code, tabId: target.id }, function(resp) {
      if (chrome.runtime.lastError) { execShowErr(eOutput, eStatus, chrome.runtime.lastError.message); return; }
      if (!resp) { execShowErr(eOutput, eStatus, "No response from background"); return; }
      execShowResult(eOutput, eStatus, resp);
    });
  });
}

function execShowResult(eOutput, eStatus, resp) {
  eStatus.textContent = resp.error ? "Error" : ("Done " + (resp.timing||0) + "ms");
  if (resp.error){ execShowErr(eOutput, eStatus, resp.error); return; }
  var r = resp.result;
  var html = "";
  if (r && typeof r === "object" && ("status" in r || "body" in r)) {
    var ok = r.status >= 200 && r.status < 300;
    html += '<div class="exec-sec"><div class="exec-lbl">Status</div><div class="' + (ok ? "exec-status-ok" : "exec-status-err") + '">' + r.status + ' ' + (ok ? "OK" : "Error") + '</div></div>';
    if (r.headers && Object.keys(r.headers).length) {
      html += '<div class="exec-sec"><div class="exec-lbl">Headers</div><pre class="exec-body" style="font-size:10px">';
      Object.entries(r.headers).forEach(function(kv){ html += esc(kv[0]) + ": " + esc(String(kv[1]).slice(0,120)) + "\n"; });
      html += '</pre></div>';
    }
    if (r.body !== undefined && r.body !== null) {
      var bodyStr = typeof r.body === "string" ? r.body : JSON.stringify(r.body, null, 2);
      var pretty = bodyStr;
      try { pretty = JSON.stringify(JSON.parse(bodyStr), null, 2); } catch(e) {}
      html += '<div class="exec-sec"><div class="exec-lbl">Body (' + bodyStr.length + ' bytes)</div><pre class="exec-body">' + esc(pretty.slice(0,8000)) + '</pre></div>';
    }
  } else {
    var rStr = (r === undefined || r === null) ? String(r) : (typeof r === "string" ? r : JSON.stringify(r, null, 2));
    html += '<div class="exec-sec"><div class="exec-lbl">Result</div><pre class="exec-body">' + esc(rStr.slice(0,6000)) + '</pre></div>';
  }
  eOutput.innerHTML = html;
}

function execShowErr(eOutput, eStatus, msg) {
  eStatus.textContent = "Error";
  eOutput.innerHTML = '<div class="exec-sec"><div class="exec-lbl" style="color:var(--red)">Error</div><pre class="exec-body" style="color:var(--red)">' + esc(String(msg)) + '</pre></div>';
}
