// Lucky Patcher – Content Script (MAIN world)
// Intercepts XHR, fetch, WebSockets, iframes, DOM mutations.

(function () {
  "use strict";

  function send(payload) {
    window.postMessage({ __lp_source: "main", payload }, "*");
  }

  // ── XHR ────────────────────────────────────────────────────────────────────
  const _XHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new _XHR();
    let method, url, reqBody;
    const reqHdrs = {};

    const origOpen = xhr.open.bind(xhr);
    xhr.open = function (m, u, ...rest) { method = m; url = u; origOpen(m, u, ...rest); };

    const origSetReqHdr = xhr.setRequestHeader.bind(xhr);
    xhr.setRequestHeader = function (name, value) {
      reqHdrs[String(name).toLowerCase()] = value;
      origSetReqHdr(name, value);
    };

    const origSend = xhr.send.bind(xhr);
    xhr.send = function (body) {
      const ts = Date.now();
      reqBody = body ? String(body).slice(0, 8000) : null;

      xhr.addEventListener("loadend", () => {
        const resHdrs = {};
        const raw = xhr.getAllResponseHeaders() || "";
        for (const line of raw.trim().split("\n")) {
          const idx = line.indexOf(":");
          if (idx > 0) resHdrs[line.slice(0,idx).trim().toLowerCase()] = line.slice(idx+1).trim();
        }
        send({
          captureType: "xhr", url, method, domain: tryDomain(url),
          statusCode: xhr.status, requestBody: reqBody,
          requestHeaders: { ...reqHdrs },
          responseHeaders: resHdrs,
          responseBody: xhr.responseType === "" || xhr.responseType === "text"
            ? String(xhr.responseText || "").slice(0, 4000) : null,
          duration: Date.now() - ts, timestamp: ts,
        });
      });
      origSend(body);
    };
    return xhr;
  }
  PatchedXHR.prototype = _XHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

  // ── Fetch ──────────────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const ts = Date.now();
    const [input, init = {}] = args;
    const url = input instanceof Request ? input.url : String(input);
    const method = (init.method || (input instanceof Request ? input.method : "GET") || "GET").toUpperCase();
    let reqBody = null;
    try { if (init.body) reqBody = String(init.body).slice(0, 8000); } catch {}

    // Capture request headers — x-auth lives here
    const reqHdrs = {};
    try {
      const hSrc = init.headers || (input instanceof Request ? input.headers : null);
      if (hSrc instanceof Headers) {
        hSrc.forEach((v, k) => { reqHdrs[k.toLowerCase()] = v; });
      } else if (hSrc && typeof hSrc === "object") {
        for (const k of Object.keys(hSrc)) reqHdrs[k.toLowerCase()] = hSrc[k];
      }
    } catch {}

    let res;
    try { res = await _fetch(...args); } catch (e) {
      send({ captureType: "fetch", url, method, domain: tryDomain(url), status: "error", error: e.message,
             requestHeaders: reqHdrs, duration: Date.now() - ts, timestamp: ts });
      throw e;
    }

    const clone = res.clone();
    (async () => {
      const hdrs = {};
      res.headers.forEach((v, k) => { hdrs[k] = v; });
      let body = null;
      const ct = res.headers.get("content-type") || "";
      if (ct.includes("json") || ct.includes("text") || ct.includes("html") || ct.includes("xml")) {
        try { body = (await clone.text()).slice(0, 4000); } catch {}
      }
      send({
        captureType: "fetch", url, method, domain: tryDomain(url),
        statusCode: res.status, requestBody: reqBody,
        requestHeaders: reqHdrs, responseHeaders: hdrs, responseBody: body,
        duration: Date.now() - ts, timestamp: ts,
      });
    })();

    return res;
  };

  // ── WebSocket ──────────────────────────────────────────────────────────────
  const _WS = window.WebSocket;
  let wsIdCounter = 0;
  window.WebSocket = function (url, protocols) {
    const ws = protocols ? new _WS(url, protocols) : new _WS(url);
    const wsId = ++wsIdCounter;
    const domain = tryDomain(url);

    ws.addEventListener("open", () => send({ captureType: "websocket", event: "open", url, domain, wsId, timestamp: Date.now() }));
    ws.addEventListener("close", (e) => send({ captureType: "websocket", event: "close", url, domain, wsId, code: e.code, reason: e.reason, timestamp: Date.now() }));
    ws.addEventListener("error", () => send({ captureType: "websocket", event: "error", url, domain, wsId, timestamp: Date.now() }));
    ws.addEventListener("message", (e) => {
      const data = typeof e.data === "string" ? e.data.slice(0, 8000) : "[binary]";
      send({ captureType: "websocket", event: "message", url, domain, wsId, payload: data, dir: "recv", timestamp: Date.now() });
    });

    const origSend = ws.send.bind(ws);
    ws.send = function (data) {
      const payload = typeof data === "string" ? data.slice(0, 8000) : "[binary]";
      send({ captureType: "websocket", event: "message", url, domain, wsId, payload, dir: "send", timestamp: Date.now() });
      origSend(data);
    };

    return ws;
  };
  window.WebSocket.prototype = _WS.prototype;
  window.WebSocket.CONNECTING = _WS.CONNECTING;
  window.WebSocket.OPEN = _WS.OPEN;
  window.WebSocket.CLOSING = _WS.CLOSING;
  window.WebSocket.CLOSED = _WS.CLOSED;

  // ── iframe tracking ────────────────────────────────────────────────────────
  function trackIframe(el) {
    const src = el.src || el.getAttribute("src") || "";
    if (src) send({ captureType: "iframe", event: "load", src, domain: tryDomain(src), tag: el.tagName, sandbox: el.sandbox?.value || null, timestamp: Date.now() });
  }

  // ── DOM mutations ──────────────────────────────────────────────────────────
  new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.tagName === "IFRAME" || node.tagName === "FRAME") trackIframe(node);
        if (node.tagName === "SCRIPT" && node.src) {
          send({ captureType: "dom", event: "script-injected", tag: "script", src: node.src, attr: "src", domain: tryDomain(node.src), timestamp: Date.now() });
        }
        if (node.tagName === "LINK" && node.rel === "preload" && node.href) {
          send({ captureType: "dom", event: "preload", tag: "link", src: node.href, attr: "href", domain: tryDomain(node.href), timestamp: Date.now() });
        }
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });

  // ── Exec code runner (bypasses page CSP — extension content scripts are trusted) ──
  window.addEventListener("message", async function(e) {
    if (!e.data || !e.data.__lp_exec_req) return;
    var reqId = e.data.reqId;
    var code  = e.data.code;
    try {
      var result;
      var isFetch = /^\s*fetch\s*\(/.test(code);
      if (isFetch) {
        // Capture the Response object and extract useful fields
        var res = await eval("(" + code.replace(/;\s*$/, "") + ")");
        if (res && typeof res.status === "number") {
          var hdrs = {};
          if (res.headers && res.headers.forEach) res.headers.forEach(function(v, k){ hdrs[k] = v; });
          var body = await res.text().catch(function(){ return null; });
          result = { status: res.status, url: res.url, headers: hdrs, body: body };
        } else { result = res; }
      } else {
        // Try expression mode first — captures IIFE return values (e.g. (function(){...return x})())
        try {
          result = await eval("(async () => " + code.replace(/;\s*$/, "") + ")()");
        } catch(exprErr) {
          if (!(exprErr instanceof SyntaxError)) throw exprErr;
          // Multi-statement code — run as statement block; explicit `return` inside works
          result = await eval("(async function(){\n" + code + "\n})()");
        }
      }
      window.postMessage({ __lp_exec_resp: true, reqId: reqId, result: result }, "*");
    } catch(err) {
      window.postMessage({ __lp_exec_resp: true, reqId: reqId, error: err.message + "\n" + (err.stack || "").split("\n").slice(0, 3).join("\n") }, "*");
    }
  });

  // ── Helpers ────────────────────────────────────────────────────────────────
  function tryDomain(url) { try { return new URL(url).hostname; } catch { return url; } }
})();
