// Lucky Patcher – Bridge (ISOLATED world)
// Receives postMessages from MAIN world, forwards to background via chrome.runtime.
window.addEventListener("message", (e) => {
  if (!e.data || e.data.__lp_source !== "main") return;
  const payload = e.data.payload;
  if (!payload) return;
  chrome.runtime.sendMessage(payload).catch(() => {});
});

// Relay exec requests from background → MAIN world and responses back.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "EXEC_CODE") return false;
  var reqId = msg.reqId;
  var timeoutId;

  function handler(e) {
    if (!e.data || !e.data.__lp_exec_resp || e.data.reqId !== reqId) return;
    window.removeEventListener("message", handler);
    clearTimeout(timeoutId);
    chrome.runtime.sendMessage({
      type: "EXEC_RESULT",
      reqId: reqId,
      result: e.data.result,
      error: e.data.error
    }).catch(() => {});
    sendResponse({ ok: true });
  }

  window.addEventListener("message", handler);
  window.postMessage({ __lp_exec_req: true, code: msg.code, reqId: reqId }, "*");

  timeoutId = setTimeout(() => {
    window.removeEventListener("message", handler);
    chrome.runtime.sendMessage({
      type: "EXEC_RESULT",
      reqId: reqId,
      error: "Exec timed out (30s)"
    }).catch(() => {});
    sendResponse({ ok: false });
  }, 30000);

  return true;
});
